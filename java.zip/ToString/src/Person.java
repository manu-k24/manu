
public class Person 
{
	private String perName;
	private String panNo;
	private int perAge;
	
	public Person(String perName, String panNo, int perAge) 
	{
		super();
		this.perName = perName;
		this.panNo = panNo;
		this.perAge = perAge;
	}
	
	public String getPerName() {
		return perName;
	}
	public void setPerName(String perName) {
		this.perName = perName;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public int getPerAge() {
		return perAge;
	}
	public void setPerAge(int perAge) {
		this.perAge = perAge;
	}

	@Override
	public String toString()           //overrided toString function
	{
		return "Person [perName=" + perName + ", panNo=" + panNo + ", perAge="
				+ perAge + "]";
	}
	
	@Override
	public boolean equals(Object obj)   //eg for equals fn 
	{
		Person tempPerson=(Person)obj;
		if(this.panNo==tempPerson.panNo)
			{
				return true;
			}
		else
			{
				return false;
			}
		
	}
	
	@Override
	public int hashCode()
	{
		return panNo.hashCode();
		//return Integer.parseInt(panNo);
	}
	
}
