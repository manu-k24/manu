package com.cg.empmgm.dao;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.exception.EmployeeException;
import com.cg.empmgm.util.DBUtil;

public class EmpDaoImpl implements EmpDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int  dataAdded=0;
	int dataDeleted=0;
	Logger empLogger=null;
	Scanner sc=new Scanner(System.in);
	public EmpDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		empLogger=Logger.getLogger("EmpDaoImpl.class");
	}
	@Override
	public int addEmp(Employee emp) throws EmployeeException
	{	
		String insertQry="INSERT INTO emp_142966(empId,ename,empSal) VALUES(?,?,?)";
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
	        pst.setInt(1, generateEmpId());
	        pst.setString(2, emp.getEmpName());
	        pst.setFloat(3, emp.getEmpSal());
	        dataAdded=pst.executeUpdate();
	        empLogger.log(Level.INFO, "Emp Inserted: "+emp);
		}
		catch (Exception e) 
		{
			empLogger.error("This is exception:"+e.getMessage());
			throw new EmployeeException(e.getMessage()); 
		}	
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new EmployeeException(e.getMessage());
			}
			
		}
		return dataAdded;
	}
	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException 
	{
		ArrayList<Employee> empList=new ArrayList<Employee>();
		String selectQry="SELECT * FROM emp_142966";
		Employee ee=null;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			
			while(rs.next())
			{
				ee=new Employee (rs.getInt("empId"),rs.getString("ename"),rs.getFloat("empSal"));
				empList.add(ee);
			}
		} 
		catch (Exception e)
		{
			throw new EmployeeException(e.getMessage()); 
		} 		
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new EmployeeException(e.getMessage());
			}
		}
		
		return empList;
	}
	@Override
	public int generateEmpId() throws EmployeeException 
	{
		String qry="Select emp_seq.NEXTVAL FROM DUAL";
		int generatedVal;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			
			rs.next();
			generatedVal=rs.getInt(1);
			
		}
		catch (Exception e) 
		{
			throw new EmployeeException(e.getMessage());     //exception not handled
		} 
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new EmployeeException(e.getMessage());
			}
		}
		return generatedVal;
	}
	@Override
	public int delEmp(int eid) throws EmployeeException 
	{
		String deleteQry="Delete from emp_142966 where empId=?";
		
		
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteQry);
			
			pst.setInt(1, eid);
			dataDeleted=pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			
			throw new EmployeeException(e.getMessage()); 
		}	
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new EmployeeException(e.getMessage());
			}
		}
		return dataDeleted;
	}
	
}

