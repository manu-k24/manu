import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;


public class TestEmpFileDemo 
{

	public static void main(String[] args) 
	{
		try 
		{
			InputStreamReader isr=new InputStreamReader(System.in);
			BufferedReader br=new BufferedReader(isr);
			System.out.println("Enter empId: ");
			int eid =Integer.parseInt(br.readLine());//readline returns as a string
			
			System.out.println("Enter ur name: ");
			String enm=br.readLine();
			
			System.out.println("Enter emp salary: ");
			float esl=Float.parseFloat(br.readLine());
			
			System.out.println("EmpId: "+eid+"\nEmp Name: "+enm+"\nEmp Salary: "+esl);
			FileWriter fw=new FileWriter("EmpInfo.txt");
			BufferedWriter bw=new BufferedWriter(fw);
			Integer eIdS=new Integer(eid);       //boxing java5 feature
			Float eslS=new Float(esl);
			bw.write("EmpId: ");
			bw.write(eIdS.toString());
			bw.write("\nEmp Name: ");
			bw.write(enm);
			bw.write("\nEmp Salary: ");
			bw.write(eslS.toString());
			bw.flush();
			System.out.println("EmpInfo written in a file");
		} 
		catch (IOException e) 
		{
			
			e.printStackTrace();
		}
		
		
	}

}
