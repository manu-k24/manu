package com.cg.corp.util;

import java.sql.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.corp.exception.FirmException;


public class DBUtil 
{
	
	public static Connection getCon() throws FirmException
	{
		Connection con=null;
		InitialContext context;
		
		try 
		{
			context=new InitialContext();
			DataSource ds=(DataSource)context.lookup("java:/jdbc/OracleDS");
			con=ds.getConnection();
		} 
		catch(NamingException e)
		{
			throw new FirmException("Problem in obtaining DataBase:"+e.getMessage());//ideally don't put user defined messages
		}
		catch (SQLException e) 
		{
			throw new FirmException("Problem in obtaining Connection:"+e.getMessage());
			
		}
	
		return con;
	}
}
