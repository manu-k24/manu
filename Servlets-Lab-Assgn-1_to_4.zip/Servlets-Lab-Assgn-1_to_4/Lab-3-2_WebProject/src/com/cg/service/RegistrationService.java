package com.cg.service;

import java.sql.SQLException;

import com.cg.dto.Registration;

public interface RegistrationService
{
	public int insertDetails(Registration register) throws SQLException;
}
