import java.util.Scanner;


public class TestMedicineInfo 
{
	public static void main(String[] args) 
	{
		Scanner sc=new  Scanner(System.in);
		int day,mon,year,mediCount,price,power,perDayIntake;
		String mediName,compName,msg,partOfAppn,typeOfSyrup;
		Date mediExp;
		
		
		System.out.println("Enter the no of medicines:");
		mediCount=sc.nextInt();
		Medicine mediArr[]=new Medicine[mediCount];
		for(int i=0;i<mediArr.length;i++)
		{
			System.out.println("Enter the medicine price: ");
			price=sc.nextInt();
			System.out.println("Enter the mediName: ");
			mediName=sc.next();
			System.out.println("Enter the compName: ");
			compName=sc.next();
			System.out.println("Enter the expiry date: ");
			System.out.println("Enter the day: ");
			day=sc.nextInt();
			
			System.out.println("Enter the month: ");
			mon=sc.nextInt();
			
			System.out.println("Enter the year: ");
			year=sc.nextInt();
			
			mediExp=new Date(day,mon,year);
			
			System.out.println("Enter what type of Medicine u want: "+
			"1. Tablet\t "+
			"2. Ointment\t"+ 
			"3. Syrup\n");
			System.out.println("Enter the choice:");
			int choice =sc.nextInt();
			
			switch (choice)
			{
				case 1: System.out.println("Enter the power of tablet in mg: ");
						power=sc.nextInt();
						msg = "Store in a cool and dry place";
						mediArr[i]=new TabletInfo(price,mediName,compName,mediExp,power,msg);
						break;
			
				case 2: System.out.println("Enter the Part of body affected: ");
						partOfAppn=sc.next();
						msg="For External Use Only";
						mediArr[i]=new OintmentInfo(price,mediName,compName,mediExp,partOfAppn,msg);
						break;
					
				default:System.out.println("Enter the Intake per day : ");
						perDayIntake=sc.nextInt();
						System.out.println("Enter the type of syrup : ");
						typeOfSyrup=sc.next();
						msg="Shake well before use";
						mediArr[i]=new SyrupInfo(price,mediName,compName,mediExp,perDayIntake,typeOfSyrup,msg);
						
			}
			
		}
					for(int i=0;i<mediCount;i++)
					{
						System.out.println(""+mediArr[i].dispMediInfo());
					}
		
		
		
		
	}
		

}
