package com.cg.gamecity.dao;
import java.util.List;
import com.cg.gamecity.dto.Games;
import com.cg.gamecity.dto.User;
import com.cg.gamecity.exception.GamecityException;

public interface GameCityDao 
{
	List<Games> getAllGames() throws GamecityException;
	long insertUsers(User user) throws GamecityException;
}