package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dbUtil.DBUtil;
import com.cg.dto.Registration;

public class RegistrationDaoImpl implements RegistrationDao
{
	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int dataAdded=0;
	@Override
	public int insertDetails(Registration register) throws SQLException 
	{
		String insertQry="Insert into RegisteredUsers( firstname,lastname,password,gender,skillset,city)"
				+ " values(?,?,?,?,?,?)";
		
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setString(1,register.getFirstName());
			pst.setString(2,register.getLastName());
			pst.setString(3,register.getPassword());
			pst.setString(4,register.getGender());
			pst.setString(5,register.getSkillSet());
			pst.setString(6,register.getCity());
			dataAdded = pst.executeUpdate();	
		
		return dataAdded;
	}
	
	

}
