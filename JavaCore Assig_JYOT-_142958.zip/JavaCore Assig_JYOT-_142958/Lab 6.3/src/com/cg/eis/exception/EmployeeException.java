package com.cg.eis.exception;

public class EmployeeException extends RuntimeException{

	public EmployeeException() {
		
	}
	

}
