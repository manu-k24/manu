package com.cg.service;

import com.cg.dto.Login;
import com.cg.user.exception.LoginException;

public interface LoginService 
{
	public Login getUserByUnm(String unm) throws LoginException;
}
