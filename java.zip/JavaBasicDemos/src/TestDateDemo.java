
public class TestDateDemo 
{

	public static void main(String[] args) 
	{
		
		Date manaliDOJ=new Date(13, 12, 2017);
		System.out.println("Mnali's date of joining is: "
		+manaliDOJ.dispDate());
		
		Date vaiDOJ=new Date(13, 12, 2013);
		System.out.println("Vaishali's date of joining is: "
		+vaiDOJ.dispDate());
		
		Date UnknownPerson=new Date();
		//UnknownPerson.initDate();
		System.out.println("unknown person DOJ is: "
		+ UnknownPerson.dispDate());
	}
}
