package com.cg.mobapp.service;

import java.util.ArrayList;

import com.cg.mobapp.bean.Mobile;
import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.exception.MobileException;

public interface MobService 
{
	public int addMob(Mobile mob) throws MobileException;
	public ArrayList<Mobile> getAllMob() throws MobileException; 
	public int delMob(int mobid) throws MobileException;
	public int UpdateMobQty(int mobid) throws MobileException;
	public ArrayList<Mobile> searchMobile(float min,float max) throws MobileException;
	
	public int addPurchase(PurchaseDetails purchase) throws MobileException;	
	public int generatePurchaseId()  throws MobileException;
	
	public boolean validateMobid(ArrayList<Mobile>  mobList,int mobileId) throws MobileException;
	
	public boolean validateName(String custName) throws MobileException;

	public boolean validateMailId(String mailId) throws MobileException;

	public boolean validatePhoneNo(String phoneNo) throws MobileException;

}
