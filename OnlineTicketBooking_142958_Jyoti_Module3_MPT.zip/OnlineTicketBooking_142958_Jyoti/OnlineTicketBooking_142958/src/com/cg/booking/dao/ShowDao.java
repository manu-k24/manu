package com.cg.booking.dao;
import java.util.List;
import com.cg.booking.dto.ShowDetails;
import com.cg.booking.exception.BookingException;

public interface ShowDao 
{
	List<ShowDetails> getAllShowDetails() throws BookingException;
	int UpdateShowDetails(String showId,float noOfSeats) throws BookingException;

}
