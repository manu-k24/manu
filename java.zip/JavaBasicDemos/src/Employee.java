
public class Employee
{
		private int empId;
		private String empName;
		private float empSal;
		private char empGender;
		
	

	public Employee()
	{
		empId=0;
		empName="Unknown";
		empSal=0.0F;
		empGender=' ';
		System.out.println("Empty constructor called");
	}

	public Employee(int eid , String enm, float esal, char gen)
	{
		this();
		empId=eid;
		empName=enm;
		empSal=esal;
		empGender=gen;
	}

	public String dispEmpDetails()
	{
		return "Employee[empId="+empId+" , empName="+empName+ " , empSal= "+empSal+" , empGender= "+empGender+"]";
	}
	
	public float calcBasicSal()
	{
		return empSal;
	}
}