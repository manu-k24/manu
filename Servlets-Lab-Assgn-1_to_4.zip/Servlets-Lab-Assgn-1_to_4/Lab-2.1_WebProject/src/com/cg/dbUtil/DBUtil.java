package com.cg.dbUtil;

import java.sql.*;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.user.exception.LoginException;

public class DBUtil 
{
	
	public static Connection getCon() throws LoginException
	{
		Connection con=null;
		InitialContext context;
		
		try 
		{
			context=new InitialContext();
			DataSource ds=(DataSource)context.lookup("java:/jdbc/OracleDS");
			con=ds.getConnection();
		} 
		catch (Exception e) 
		{
			throw new LoginException(e.getMessage());
			
		}
	
		return con;
	}
}
