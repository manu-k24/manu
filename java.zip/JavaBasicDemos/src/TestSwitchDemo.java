
public class TestSwitchDemo
{

	public static void main(String[] args) 
	{
		
		int day=Integer.parseInt(String ar[0]);
		switch(day)
		{
		case 1: System.out.println("Its a monday");
		break;
		case 2: System.out.println("Its a tuesday");
		break;
		case 3: System.out.println("Its a wednesday");
		break;
		case 4: System.out.println("Its a thurday");
		break;
		case 5: System.out.println("Its a friday");
		break;
		case 6: System.out.println("Its a saturday");
		break;
		case 7: System.out.println("Its a sunday");
		break;
		default: System.out.println("Its a weekday");
		break;
		}
	}

}
