
public class TestEmployeeDetails {

	public static void main(String[] args) 
	{
		Employee manaliDetails=new Employee(101, "Manali", 20000,'F');
		System.out.println("Manali's Details are: "
				+manaliDetails.dispEmpDetails());

		Employee vrushaliDetails=new Employee(102, "Vrushali", 30000,'F');
		System.out.println("Vrushali's Details are: "
				+manaliDetails.dispEmpDetails());
		
		Employee unknownDetails=new Employee();
		System.out.println("Unknown Person's Details are: "
				+unknownDetails.dispEmpDetails());

	}

}
