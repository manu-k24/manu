
public class OintmentInfo extends Medicine
{
	private String partOfAppn;
	private String msg="For External Use Only";

	public OintmentInfo(int price, String mediName, String compName,
			Date expDate, String partOfAppn, String msg) 
	{
		super(price, mediName, compName, expDate);
		this.partOfAppn = partOfAppn;
		this.msg= msg;
	}

	public String dispMediInfo() {
		return "OintmentInfo [partOfAppn=" + partOfAppn + ", msg=" + msg
				+ ", expDate=" + expDate.dispDate() + "]";
	}

	
}
