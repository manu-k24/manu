import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
public class TestDeSerializationFor_N_Emp 
{

	public static void main(String[] args) 
	{	
		Emp e1[]=new Emp[nums];
		FileInputStream fis;
		ObjectInputStream ois;
		try
		{
			fis=new FileInputStream("N_EmpData.obj");
			ois=new ObjectInputStream(fis);
			for(int i=0;i<e1.length;i++)
			{
			e1[i]=(Emp)ois.readObject();  //type casting is required
			System.out.println(e1[i]);
			}
			System.out.println("Emp object is written in a file");
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		
		
		
	}
	
}