package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.ShowDetails;
import com.cg.exception.BookingException;
import com.cg.util.DBUtil;


public class ShowDaoImpl implements ShowDao
{
	Connection con;
	@Override
	public ArrayList<ShowDetails> getShowDetails() throws BookingException
	{
		ArrayList<ShowDetails> showList = new ArrayList<ShowDetails>();
		con = DBUtil.getConnection();
		try
		{
			
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(QueryMapper.SELECT_ALL_DETAILS);
			while (rs.next()) 
			{
				ShowDetails sd = new ShowDetails();
				sd.setShowId(rs.getString("ShowId"));
				sd.setShowName(rs.getString("ShowName"));
				sd.setLocation(rs.getString("Location"));
				sd.setShowDate(rs.getDate("ShowDate"));
				sd.setAvailableSeats(rs.getInt("AvSeats"));
				sd.setPrice(rs.getDouble("PriceTicket"));
				showList.add(sd);
			}
		} catch (SQLException e) 
		{
			// e.printStackTrace();
			throw new BookingException("Problem in fetching show Details");
		} 
		return showList;
	}
	
	
	
	
	
	
	@Override
	public ShowDetails getShowDetail(String showid) throws BookingException 
	{
		con = DBUtil.getConnection();
		ShowDetails show=null;
		try 
		{
			PreparedStatement pst=con.prepareStatement(QueryMapper.SELECT_DETAILS);
			pst.setString(1, showid);
			ResultSet rst=pst.executeQuery();
			rst.next();
			
			show = new ShowDetails();
			show.setShowId(rst.getString("ShowId"));
			show.setShowName(rst.getString("ShowName"));
			show.setLocation(rst.getString("Location"));
			show.setShowDate(rst.getDate("ShowDate"));
			show.setAvailableSeats(rst.getInt("AvSeats"));
			show.setPrice(rst.getDouble("PriceTicket"));

		} catch (SQLException e) {
			// e.printStackTrace();
			throw new BookingException("Problem while fetching show details");
		}
		return show;
	
}
	@Override
	public int updateShowDetails(int seats, String showname)
			throws BookingException 
	{
		
		int dataUpdated=0;
		con=DBUtil.getConnection();
       
        try
        {
        	PreparedStatement pst=con.prepareStatement(QueryMapper.UPDATE_QUERY);
            pst.setInt(1, seats);
            pst.setString(2, showname);
            pst.executeUpdate();
        } 
        catch(SQLException e)
		{
			throw new BookingException("Problem in updating Show Details table:"+e.getMessage());
		}
        
        return dataUpdated;
		
		
	}
	
}
