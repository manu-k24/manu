package com.cg.recruitapp.service;

import java.util.regex.Pattern;

import com.cg.recruitapp.bean.ContactBook;
import com.cg.recruitapp.dao.ContactBookDao;
import com.cg.recruitapp.dao.ContactBookDaoImpl;
import com.cg.recruitapp.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService
{
	ContactBookDao contactDao=null;
	
	public ContactBookServiceImpl()
	{
		contactDao=new ContactBookDaoImpl();
	}

	@Override
	public int addEnquiry(ContactBook contact) throws ContactBookException
	{
		return contactDao.addEnquiry(contact);
	}

	@Override
	public int generateEnquiryId() throws ContactBookException 
	{
		return contactDao.generateEnquiryId();
	}

	@Override
	public ContactBook getEnquiryDetails(int EnquiryId) throws ContactBookException
	{
		
		return contactDao.getEnquiryDetails(EnquiryId);
	}

	/*@Override
	public boolean validateContactBook(ContactBook contact) throws ContactBookException 
	{
		return false;
	}*/

	@Override
	public boolean validateFirstName(String fName) throws ContactBookException 
	{
		String fnamePattern="[A-Z][a-z]+";
		if(Pattern.matches(fnamePattern, fName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Only characters allowed and starts with Capital e.g Manali");
		}	
		
		/*if(fName.length()!=0)
		{
			return true;
		}
		else
		{
			throw new ContactBookException("First Name cannot be empty");
		}*/
	}

	@Override
	public boolean validateLastName(String lName) throws ContactBookException 
	{
		String lnamePattern="[A-Z][a-z]+";
		if(Pattern.matches(lnamePattern, lName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Only characters allowed and starts with Capital e.g Kadam");
		}	
		
		/*if(lName.length()!=0)
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Last Name cannot be empty");
		}*/
	}

	@Override
	public boolean validatePrefLocation(String pLocation)
			throws ContactBookException 
	{
		if(pLocation.length()!=0)
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Preferred Location cannot be empty");
		}
	}

	@Override
	public boolean validateDomain(String pDomain) throws ContactBookException 
	{
		if(pDomain.length()!=0)
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Domain cannot be empty");
		}	
	}

	@Override
	public boolean validateContactNo(String contactNo)
			throws ContactBookException
	{
		String numPattern="[7-9][0-9]{9}";   //"[0-9]{10}$"
		if(Pattern.matches(numPattern,contactNo ))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Enter valid Phone No");
		}	
	}

}
