package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dao.MobilePurchaseDao;
import com.cg.mpa.dao.MobilePurchaseDaoImpl;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public class MobileServiceImpl implements MobileService
{

	MobilePurchaseDao mdao=new MobilePurchaseDaoImpl();
	@Override
	public List<Mobile> getAllMob() throws MobileException 
	{	
		return mdao.getAllMob();
	}

	@Override
	public Mobile getMobile(int mobId) throws MobileException 
	{
		return mdao.getMobile(mobId);
	}

	@Override
	public int addPurchaseDetails(PurchaseDetails purchase)
			throws MobileException 
	{		
		return mdao.addPurchaseDetails(purchase);
	}

}
