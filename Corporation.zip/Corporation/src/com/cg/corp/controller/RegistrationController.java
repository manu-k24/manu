package com.cg.corp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.corp.dto.FirmMaster;
import com.cg.corp.exception.FirmException;
import com.cg.corp.service.FirmMasterService;
import com.cg.corp.service.FirmMasterServiceImpl;





@WebServlet(urlPatterns={"/home","/register","/activate"})
public class RegistrationController extends HttpServlet
{
	private static final long serialVersionUID = 1L;

    public RegistrationController() 
    {
        super();
  
    }

	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	public void destroy()
	{
	
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url = request.getServletPath();
		String targetUrl = "";
		FirmMasterService fmSer =new  FirmMasterServiceImpl();
		HttpSession sess = null;
		switch(url)
		{
		case "/home":
			try 
			{
				//List<FirmMaster> firmList = fmSer.getAllData();
				//request.setAttribute("firmList", firmList);
				System.out.println("null");
				targetUrl = "Home.jsp";
			} 
			catch (Exception e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
		break;
		
		case "/register":
			FirmMaster fm = new FirmMaster();
			
			fm.setOwner_name(request.getParameter("uName"));
			fm.setBusiness_name(request.getParameter("bName"));
			fm.setEmailId(request.getParameter("emailId"));
			fm.setMobileNo(request.getParameter("mob"));
			fm.setIsActive('N');
			
			sess = request.getSession(true);
			
			try 
			{
				fmSer.addFirmDetails(fm);
				request.setAttribute("fm", fm);
				targetUrl="Success.jsp";
			} 
			catch (FirmException e)
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}
		break;
		
		case "/activate":
			String em=request.getParameter("email");
			String code=request.getParameter("aCode");
			long c = Long.parseLong(code);
			FirmMaster firm;
			sess = request.getSession(false);
			try {
				firm = fmSer.getFirmData(c);
				if((firm.getEmailId().equalsIgnoreCase(em)) && (firm.getFirmId() == c))
				{
					sess.setAttribute("EmailObj", em);   //(key,value)
					targetUrl="ActivationSuccess.jsp";
				}
				else
				{
					response.sendRedirect("Error.jsp");				
				}
			} 
			catch (FirmException e) 
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}	
			
		break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}

}
