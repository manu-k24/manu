package com.cg.recruitapp.dao;

import com.cg.recruitapp.bean.ContactBook;
import com.cg.recruitapp.exception.ContactBookException;

public interface ContactBookDao 
{
	public int addEnquiry(ContactBook contact) throws ContactBookException;
	public int generateEnquiryId() throws ContactBookException;
	public ContactBook getEnquiryDetails(int EnquiryId) throws ContactBookException;
	
}
