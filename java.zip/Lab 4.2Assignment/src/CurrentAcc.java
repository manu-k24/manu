public class CurrentAcc extends Account{
    private double overDraftLimit = 2000;

    public CurrentAcc() {
        super();
        
    }

    public CurrentAcc(Person accHolder, long accNumber, double balance) {
        super(accHolder, accNumber, balance);
        
    }

    @Override
    public void withdraw(double amount) {
        if(amount<=overDraftLimit)
        super.withdraw(amount);
        else 
            System.out.println("Withdrawal not possible as amount exceeded Over Draft Limit of 2000");
    }
}
    
