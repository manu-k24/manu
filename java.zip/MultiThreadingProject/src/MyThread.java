
//public class MyThread extends Thread
public class MyThread implements Runnable
{
	String msg;
	public  MyThread(String msg)
	{
		this.msg=msg;
	}
	@Override
	public void run()
	{
		Thread currThread=Thread.currentThread();
		if(currThread==TestSleepDemo.t2)
		{
			try 
			{
				TestSleepDemo.t1.join();
			} 
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		
		for(int j=1;j<=3;j++)
		{
			try 
			{
				System.out.println(currThread.getName()+"Says: "+msg);
				Thread.sleep(2000);
			} catch (InterruptedException e) 
			{
				
				e.printStackTrace();
			}
		}
		
	}
}
