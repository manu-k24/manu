import java.util.Scanner;


public class TestEmpInfo
{

	public static void main(String[] args) 
	{
		Scanner sc=new  Scanner(System.in);
		Employee Emps[]=new Employee[3];
		
		int empId;
		String empName;
		float empSal;
		char empGender;
		
		for(int i=0;i<Emps.length;i++)
		{
			System.out.println("Enter Employee Id: ");
			empId=sc.nextInt();
			
			System.out.println("Enter Employee Name: ");
			empName=sc.next();
			
			System.out.println("Enter Employee salary: ");
			empSal=sc.nextFloat();
			
			System.out.println("Enter the gender: ");
			empGender=sc.next().charAt(0);
			
			Emps[i]=new Employee(empId,empName,empSal,empGender);
		}
		
		for(int j=0;j<Emps.length;j++)
		{
			System.out.println(" DOJ: "+Emps[j].dispEmpDetails());
		}
	
	}

}
