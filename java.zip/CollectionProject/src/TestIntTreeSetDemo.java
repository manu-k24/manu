import java.util.TreeSet;


public class TestIntTreeSetDemo 
{

	public static void main(String[] args) 
	{
		TreeSet<Integer> intSet=new TreeSet<Integer>();
		
		Integer i1=new Integer(-40);
		Integer i2=new Integer(20);
		Integer i3=new Integer(20);
		Integer i4=new Integer(50);
		
		intSet.add(i1);
		intSet.add(i2);
		intSet.add(i3);
		intSet.add(i4);
		
		System.out.println("*******Without Iterator********");
		System.out.println(intSet);

	}

}
