
public class Person 
{
	private String firstName;
	private String lastName;
	private char gender;
	private int age;
	private float weight;
	public String mobNo;
	
	public Person()
	{
		
		
	}
	
	//Getter Setter functions defined for First name, Last name and Age
	
	public String getFirstName() 
	{
		return firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public int getAge() 
	{
		return age;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public void setAge(int age) 
	{
		this.age = age;
	}

	public Person(String mobNo)
	{
		this.mobNo=mobNo;
	}
	
	
	
	
	
}
