package com.cg.recruitapp.dao;

import java.sql.*;
import java.util.Scanner;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.recruitapp.bean.ContactBook;
import com.cg.recruitapp.exception.ContactBookException;
import com.cg.recruitapp.service.ContactBookService;
import com.cg.recruitapp.util.DBUtil;

public class ContactBookDaoImpl implements ContactBookDao
{
	Logger contactLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int dataAdded=0;
	Scanner sc=new Scanner(System.in);
	
	public ContactBookDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		contactLogger=Logger.getLogger("ContactBookServiceImpl.class");
	}

	@Override
	public int addEnquiry(ContactBook contact) throws ContactBookException 
	{
		String insertQry="INSERT INTO enquiry(enqryId,firstName,lastName,contactNo,domain,city) VALUES(?,?,?,?,?,?)";

		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
	        pst.setInt(1, generateEnquiryId());
	        pst.setString(2, contact.getfName());
	        pst.setString(3, contact.getlName());
	        pst.setString(4, contact.getContactNo());
	        pst.setString(5, contact.getpDomain());
	        pst.setString(6, contact.getpLocation());
	        dataAdded=pst.executeUpdate();
	        contactLogger.log(Level.INFO, "Enquiry Details Inserted: "+contact);
		}
		catch (Exception e) 
		{			
			throw new ContactBookException(e.getMessage()); 
		}	
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{	
				contactLogger.error("This is exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}
			
		}
		return dataAdded;
	}

	@Override
	public ContactBook getEnquiryDetails(int EnquiryId)	throws ContactBookException 
	{
		String selectQry="Select enqryId,firstName,lastName,contactNo,domain,city FROM enquiry WHERE enqryId=?";
		
		try 
		{
			//ContactBookService contactSer=new ContactBookService();
			pst.setInt(1, EnquiryId);
			rs=pst.executeQuery();
			if(rs.next())
			{
				ContactBook contact=new ContactBook();
				contact.setfName(rs.getString("First name"));
				contact.setlName(rs.getString("Last name"));
				contact.setContactNo(rs.getString(" Contact no"));
				contact.setpDomain(rs.getString("Preferred Domain"));
				contact.setpLocation(rs.getString("Preffered Location"));
			}
			//if(contact.getFirstName()==null)
			//{
			//	return null;
			//}
		}
		catch (Exception e) 
		{
			throw new ContactBookException(e.getMessage()); 
		}
		finally
		{
			try 
			{	rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{				
				throw new ContactBookException(e.getMessage());
			}			
		}
		return (ContactBook) rs;
	}

	@Override
	public int generateEnquiryId() throws ContactBookException
	{
		String qry="Select enquiries_seq.NEXTVAL FROM DUAL";
		int generatedVal;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			
			rs.next();
			generatedVal=rs.getInt(1);			
		}
		catch (Exception e) 
		{
			throw new ContactBookException(e.getMessage());     //exception not handled
		} 
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new ContactBookException(e.getMessage());
			}
		}
		return generatedVal;
	}

}
