package com.cg.gamecity.dao;

public interface QueryMapper 
{
	String SELECT_ALL_ONLINEGAMES="SELECT * FROM onlinegames";
	String INSERT_QUERY="INSERT INTO usersDetails VALUES(?,?,?,?)";
	String SELECT_SEQUENCE="SELECT seq_user.NEXTVAL FROM dual";
}
