
public class WageEmp extends Employee
{
	private int noOfHours;
	private int ratePerHour;
	
	public WageEmp()
	{
		super();                
	}

	public WageEmp(int empId,String empName,float empSal,int noOfHours, int ratePerHour) 
	{
		super(empId, empName, empSal);
		this.noOfHours = noOfHours;
		this.ratePerHour = ratePerHour;
	}
	
	public float calcEmpBasicSal()
	{
		return super.calcEmpBasicSal()+(ratePerHour*noOfHours*22);
	}
	
	public float calcEmpAnnSal()
	{
		return calcEmpBasicSal()*12;
	}
	
	

	
	
	
}
