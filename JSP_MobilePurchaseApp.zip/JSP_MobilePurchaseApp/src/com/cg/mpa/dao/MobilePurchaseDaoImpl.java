package com.cg.mpa.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.util.DBUtil;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao
{

	Connection con = null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public List<Mobile> getAllMob() throws MobileException 
	{
		List<Mobile> mobList=new ArrayList<Mobile>();
		con=DBUtil.getCon();
		try {
			st=con.createStatement();
			rs=st.executeQuery(QuerryMapper.SELECT_ALL_MOBILES);
			while(rs.next())
			{
				Mobile m=new Mobile();
				m.setMobId(rs.getInt("mobileid"));
				m.setMobName(rs.getString("name"));
				m.setPrice(rs.getFloat("price"));
				m.setQuantity(rs.getInt("quantity"));
				mobList.add(m);
			}
		} 
		catch (SQLException e) 
		{
			throw new MobileException("Problem in Fetching mobile list"+e.getMessage());
		}
		
		return mobList;
	}

	@Override
	public Mobile getMobile(int mobId) throws MobileException 
	{
		Mobile m=null;
		con=DBUtil.getCon();
		try {			
			pst=con.prepareStatement(QuerryMapper.SELECT_MOBILE);
			pst.setInt(1, mobId);
			rs=pst.executeQuery();
			if(rs.next())
			{
				m=new Mobile();
				m.setMobId(rs.getInt("mobileid"));
				m.setMobName(rs.getString("name"));
				m.setPrice(rs.getFloat("price"));
				m.setQuantity(rs.getInt("quantity"));
			}
			else
			{
				throw new MobileException("Mobile not Found");
			}
		} 
		catch (SQLException e) 
		{
			throw new MobileException("Problem in Fetching mobile list"+e.getMessage());
		}
		return m;
	}
	
	private int generatePurchaseId() throws MobileException
	{
		int pid=0;
		con=DBUtil.getCon();
		try
		{
			st=con.createStatement();
			rs=st.executeQuery(QuerryMapper.SELECT_SEQUENCE);
			rs.next();
			pid=rs.getInt(1);
		} 
		catch (SQLException e) 
		{
			throw new MobileException("Problem in generating purchase id"+e.getMessage());
		}		
		return pid;
	}

	@Override
	public int addPurchaseDetails(PurchaseDetails purchase) throws MobileException 
	{
		con=DBUtil.getCon();
		purchase.setPurchaseId(generatePurchaseId());           
		try 
		{
			pst=con.prepareStatement(QuerryMapper.INSERT_QUERY);
			pst.setInt(1, purchase.getPurchaseId());
			pst.setString(2, purchase.getCustName());
			pst.setString(3, purchase.getMailId());
			pst.setString(4, purchase.getPhoneNo());
			pst.setDate(5, Date.valueOf(purchase.getPurchaseDate()));   //local date to sql date
			pst.setInt(6, purchase.getMobileId());
			pst.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new MobileException("Problem in inserting purchase Details"+e.getMessage());
		}
		return purchase.getPurchaseId();
	}

}
