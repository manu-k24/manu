package com.cg.service;

import com.cg.dao.LoginDao;
import com.cg.dao.LoginDaoImpl;
import com.cg.dto.Login;
import com.cg.user.exception.LoginException;

public class LoginServiceImpl implements LoginService
{
	LoginDao loginDao=null;
	
	public LoginServiceImpl()
	{
		loginDao=new LoginDaoImpl();
	}
	
	@Override
	public Login getUserByUnm(String unm) throws LoginException 
	{
		return loginDao.getUserByUnm(unm);
	}

}
