package com.cg.gamecity.dto;

public class User 
{
	private long userId;
	private String userName;
	private String userAddress;
	private double cardAmt;
	
	public long getUserId() 
	{
		return userId;
	}
	public void setUserId(long userId) 
	{
		this.userId = userId;
	}
	public String getUserName() 
	{
		return userName;
	}
	public void setUserName(String userName) 
	{
		this.userName = userName;
	}
	public String getUserAddress() 
	{
		return userAddress;
	}
	public void setUserAddress(String userAddress) 
	{
		this.userAddress = userAddress;
	}
	public double getCardAmt() 
	{
		return cardAmt;
	}
	public void setCardAmt(double cardAmt) 
	{
		this.cardAmt = cardAmt;
	}
	
	public User() 
	{
		super();
	}
	
	public User(long userId, String userName, String userAddress, double cardAmt) 
	{
		super();
		this.userId = userId;
		this.userName = userName;
		this.userAddress = userAddress;
		this.cardAmt = cardAmt;
	}
	
	@Override
	public String toString() 
	{
		return "User [userId=" + userId + ", userName=" + userName
				+ ", userAddress=" + userAddress + ", cardAmt=" + cardAmt + "]";
	}
}
