
public class DisplayPersonInfo 
{

	public static void main(String[] args) 
	{
		String firstName="Divya";
		String lastName="Bharathi";
		char gender='F';
		int age=20;
		double weight=85.55;
	
		System.out.println("First Name: "+firstName);
		System.out.println("Last Name: "+lastName);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
	
	}
	
}
