//This program adds data to table with predefined values
import java.sql.*;


public class TestEmpAddDemo 
{

    public static void main(String[] args) 
    {
        Connection con = null;
        Statement st = null;

        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
            
            String insertQry = "insert into emp_142966(empId,ename,empSal) VALUES(666,'Ronak',80000)";
            st = con.createStatement();
            
            int data = st.executeUpdate(insertQry);
            System.out.println("Data Inserted in table :"+data);
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        } 
    }

}
