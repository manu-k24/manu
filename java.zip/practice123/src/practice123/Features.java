package practice123;

import static java.lang.Math.PI;
import static java.lang.Math.pow;

public class Features 
{

	public static void main(String[] args) 
	{
		System.out.println("PI= "+PI);
		System.out.println("Cube of 2= "+pow(2,3));
	}

}
