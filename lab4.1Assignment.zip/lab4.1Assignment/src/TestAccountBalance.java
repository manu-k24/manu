import java.util.Random;
public class TestAccountBalance 
{

	public static void main(String[] args) 
	{
		Person p1=new Person();
		
		p1.setName("Smith");
		p1.setAge(22);
		
		System.out.println("Name: "+p1.getName());
		System.out.println("Age: "+p1.getAge());
		
		
		Account smith=new Account();
		long accNum = new Random().nextLong();
		
		smith.setAccNum(accNum);
		smith.setBalance(2000);
		
		System.out.println("Account Number: "+smith.getAccNum());
		System.out.println("Initial Balance: "+smith.getBalance());
		
		
		Person p2=new Person();
		
		p2.setName("Kathy");
		p2.setAge(24);
		
		System.out.println("First Name: "+p2.getName());
		System.out.println("Age: "+p2.getAge());
		
		Account Kathy=new Account();
		
		Kathy.setAccNum(accNum);
		Kathy.setBalance(2000);
		
		System.out.println("Account Number: "+Kathy.getAccNum());
		System.out.println("Initial Balance: "+Kathy.getBalance());
	}

}
