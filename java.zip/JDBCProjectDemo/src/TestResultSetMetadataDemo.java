import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Scanner;


public class TestResultSetMetadataDemo 
{

	public static void main(String[] args) 
	{
		Connection con = null;
	    PreparedStatement pst;
	    Statement st=null;
		ResultSet rs=null;
		ResultSetMetaData rsmd=null;
		
		  try
	      {
	      	Scanner sc=new Scanner(System.in);
	      	
	        Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
	        con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
	          
	        st=con.createStatement();     //gives statement object
			rs=st.executeQuery("SELECT * from Emp_142966");
			rsmd=rs.getMetaData();
			int columnCount=rsmd.getColumnCount();
	        System.out.println("No of columns: "+columnCount);
	        for(int i=1;i<columnCount;i++)
	        {
	        	 System.out.println("Column Name: "+rsmd.getColumnClassName(i));
	        	 System.out.println("Column Label: "+rsmd.getColumnLabel(i));
	        	 System.out.println("Column Type: "+rsmd.getColumnType(i));
	        	 System.out.println("Column Type Name: "+rsmd.getColumnTypeName(i));
	        	 System.out.println("**********");
	        	 
	        }
	      }
		  catch (Exception e)
		    {
				e.printStackTrace();
			}
			

	}

}
