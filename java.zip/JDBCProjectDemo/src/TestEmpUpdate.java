//Update emp_142966 table by adding sal of 10000 to those having salary less than 20000
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class TestEmpUpdate
{

	public static void main(String[] args) 
	{
		 Connection con = null;
	     PreparedStatement pst;
	     Scanner sc=null;
	     try
	      {
	      	sc=new Scanner(System.in);
	      	
	        Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
	        con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
	          
	        String updateQry = "Update emp_142966 set empsal=(empsal+10000) where empsal<50000";
	        pst=con.prepareStatement(updateQry);
	        int dataUpdated;
	        dataUpdated=pst.executeUpdate();
	        System.out.println("Data is added...."+dataUpdated);
	      }
         
	      
	     catch (Exception e) 
	      {
	          e.printStackTrace();
	      } 
	}

}
