package com.cg.gamecity.service;
import java.util.List;

import com.cg.gamecity.dao.GameCityDao;
import com.cg.gamecity.dao.GameCityDaoImpl;
import com.cg.gamecity.dto.Games;
import com.cg.gamecity.dto.User;
import com.cg.gamecity.exception.GamecityException;

public class GameCityServiceImpl implements GameCityService
{
	GameCityDao gdao=new GameCityDaoImpl();
	@Override
	public List<Games> getAllGames() throws GamecityException 
	{
		return gdao.getAllGames();
	}

	@Override
	public long insertUsers(User user) throws GamecityException 
	{
		return gdao.insertUsers(user);
	}
}
