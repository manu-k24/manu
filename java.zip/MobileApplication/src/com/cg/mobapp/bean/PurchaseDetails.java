package com.cg.mobapp.bean;

import java.time.LocalDate;

public class PurchaseDetails
{
	private int purchaseId;
	private String custName;
	private String mailId;
	private String phoneNo;
	private LocalDate purchaseDate;
	private int mobileId;
	
	public PurchaseDetails()
	{
		
	}
	public PurchaseDetails(int purchaseId, String custName, String mailId,
			String phoneNo, LocalDate purchaseDate, int mobileId)
	{
		super();
		this.purchaseId = purchaseId;
		this.custName = custName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}
	
	public int getPurchaseId() 
	{
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) 
	{
		this.purchaseId = purchaseId;
	}
	public String getCustName() 
	{
		return custName;
	}
	public void setCustName(String custName)
	{
		this.custName = custName;
	}
	public String getMailId() 
	{
		return mailId;
	}
	public void setMailId(String mailId)
	{
		this.mailId = mailId;
	}
	public String getPhoneNo() 
	{
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo)
	{
		this.phoneNo = phoneNo;
	}
	public int getMobileId() 
	{
		return mobileId;
	}
	public void setMobileId(int mobileId) 
	{
		this.mobileId = mobileId;
	}
	public LocalDate getPurchaseDate() 
	{
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) 
	{
		this.purchaseDate = purchaseDate;
	}
	@Override
	public String toString() 
	{
		return "PurchaseDetails [purchaseId=" + purchaseId + ", custName="
				+ custName + ", mailId=" + mailId + ", phoneNo=" + phoneNo
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId
				+ "]";
	}
	
	
	
	
}
