
public class SalesManager extends WageEmp
{
	private float sales;
	private float comm;
	
	
	public SalesManager()
	{
		super();
	}
	
	public SalesManager(int empId,String empName,float empSal,int noOfHours, int ratePerHour,float sales, float comm) 
	{
		super(empId, empName, empSal,noOfHours,ratePerHour);
		this.sales = sales;
		this.comm = comm;
	}
	
	public float calcEmpBasicSal()
	{
		return super.calcEmpBasicSal()+(sales*comm);
	}
	

	public float calcEmpAnnSal()
	{
		return calcEmpBasicSal()*12;
	}
	
	
	
}
