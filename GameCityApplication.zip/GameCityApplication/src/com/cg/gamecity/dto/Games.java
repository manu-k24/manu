package com.cg.gamecity.dto;

public class Games 
{
	private String gameName;
	private double gameAmt;
	
	public String getGameName() 
	{
		return gameName;
	}
	public void setGameName(String gameName) 
	{
		this.gameName = gameName;
	}
	public double getGameAmt() 
	{
		return gameAmt;
	}
	public void setGameAmt(double gameAmt) 
	{
		this.gameAmt = gameAmt;
	}
	public Games()
	{
		super();
	}
	
	public Games(String gameName, double gameAmt) 
	{
		super();
		this.gameName = gameName;
		this.gameAmt = gameAmt;
	}
	
	@Override
	public String toString() 
	{
		return "Games [gameName=" + gameName + ", gameAmt=" + gameAmt + "]";
	}
}
