package com.cg.service;

import java.sql.SQLException;

import com.cg.dao.RegistrationDao;
import com.cg.dao.RegistrationDaoImpl;
import com.cg.dto.Registration;

public class RegistrationServiceImpl implements RegistrationService
{
	RegistrationDao registerDao =null;
	public RegistrationServiceImpl()
	{
		registerDao=new RegistrationDaoImpl();
	}
	@Override
	public int insertDetails(Registration register) throws SQLException 
	{		
		return registerDao.insertDetails(register);
	}

}
