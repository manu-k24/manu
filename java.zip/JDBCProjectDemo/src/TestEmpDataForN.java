
//User can enter data dynamically for N employees
import java.sql.*;
import java.util.Scanner;


public class TestEmpDataForN 
{
	public static void main(String[] args) 
  {
     Connection con = null;
     PreparedStatement pst;
     Scanner sc=null;

      try
      {
      	sc=new Scanner(System.in);
      	
          Class.forName("oracle.jdbc.driver.OracleDriver"); // throws an exception
          con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
          
          String insertQry = "insert into emp_142966(empId,ename,empsal) VALUES(?,?,?)";
          pst=con.prepareStatement(insertQry);
          int dataAdded;
          
          System.out.println("Enter the number: ");
          int n=sc.nextInt();
          for(int i=0;i<n;i++)
          {
	          System.out.println("Enter Id: ");
	          int empId=sc.nextInt();
	          System.out.println("Enter Name: ");
	          String ename=sc.next();
	          System.out.println("Enter Salary: ");
	          float empSal=sc.nextFloat();
	          
	          pst.setInt(1, empId);
	          pst.setString(2, ename);
	          pst.setFloat(3, empSal);
	          dataAdded=pst.executeUpdate();
	          System.out.println("Data is added...."+dataAdded); 
          }
         
      }
      catch (Exception e) 
      {
          e.printStackTrace();
      } 
  }

}
