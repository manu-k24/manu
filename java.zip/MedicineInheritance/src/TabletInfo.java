

public class TabletInfo extends Medicine
{
	private int power;
	private String msg="Store in a cool and dry place";

	public TabletInfo(int price, String mediName, String compName,
			Date expDate, int power,String msg) 
	{
		super(price, mediName, compName, expDate);
		this.power = power;
		this.msg=msg;
	}

	public String dispMediInfo() 
	{
		return "TabletInfo [power=" + power + ", msg=" + msg + ", expDate="
				+ expDate.dispDate() + "]";
	}
	
	
}
