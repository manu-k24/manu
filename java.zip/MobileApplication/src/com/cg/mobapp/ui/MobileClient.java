package com.cg.mobapp.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobapp.bean.Mobile;
import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.exception.MobileException;
import com.cg.mobapp.service.MobService;
import com.cg.mobapp.service.MobServiceImpl;

public class MobileClient
{
	static Scanner sc=null;
	static MobService mobSer=null;
	
	
	public static void main(String[] args) 
	{
		mobSer=new MobServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		
		while(true)
		{
			System.out.println("What do u want to do?");
			System.out.println("1. Insert customer and purchase details\n"
							  +"2. Fetch details of all mobiles available in the shop\n"
							  +"3.Delete Mobile Details\n"
							  +"4. Search Mobile Data\n"
							  +"5. Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:	insertPurchaseDetails();	
					break;
			case 2:	fetchAllMobDetails();
					break;
			case 3:	delMobDetails();
					break;
			case 4: searchMobileDetails();
					break;
			case 5:	System.exit(0);
					break;	
			default: System.out.println("Invalid Choice");
			}
			
		}
		
	}
//**************************main ends*********************************
	
	private static void searchMobileDetails() 
	{
		float min,max;
		System.out.println("Enter the min price: ");
		min=sc.nextFloat();
		System.out.println("Enter the max price: ");
		max=sc.nextFloat();
		
		try 
		{
			ArrayList<Mobile> mobList=mobSer.searchMobile(min, max);
			if (mobList==null)
			{
				System.out.println("Not in the range:  ");
			}
			else
			{
				for(Mobile mob:mobList)
				{
					System.out.println(mob);
				}
			}
		} 
		catch (MobileException e)
		{
			
			e.printStackTrace();
		}
		
	}

	private static void UpdateMobDetails(int mobid) 
	{		
		int dataUpdated=0;
		
		//System.out.println("Enter the mobile Id: ");
		//mobid=sc.nextInt();
		try 
		{			
			
			dataUpdated = mobSer.UpdateMobQty(mobid);		
			if (dataUpdated==1)
			{
				System.out.println("Mobile Details Updated:");
			}
			else
			{
				System.out.println("May be some Exception while Updation");
			}
		} 
		catch (MobileException e)
		{
			System.out.println(e.getMessage());
		}
	}
//*****************************************************************************************
	private static void delMobDetails()
	{
		System.out.println("Enter the mobile Id: ");
		int mobid=sc.nextInt();
		try 
		{
			ArrayList<Mobile> mobList=mobSer.getAllMob();
			if(mobSer.validateMobid(mobList, mobid))
			{
				int dataDeleted=mobSer.delMob(mobid);
				if (dataDeleted==1)
				{
					System.out.println("Mobile Data Deleted:");
				}
				else
				{
					System.out.println("May be some Exception while Deletion");
				}
			}
		}
		catch (MobileException e) 
		{
			System.out.println(e.getMessage());
		}
		
	}

//*****************************************************************************************

	private static void fetchAllMobDetails() 
	{
		try 
		{
			ArrayList<Mobile> mobList=mobSer.getAllMob();
			for(Mobile ee:mobList) 
			{
				System.out.println(ee);
			}
		} 
		catch (MobileException e)
		{
			System.out.println("Some exception while fetching data");
			e.printStackTrace();
		}
		
	}
//************************************************************************************
	private static void insertPurchaseDetails()
	{
		System.out.println("Enter Quantity of mobile: ");
		int qty=sc.nextInt();
		PurchaseDetails pp=new PurchaseDetails();
		try
		{
			if(qty>0)
			{		
				System.out.println("Enter Customer Name: ");
				String enm=sc.next();
				if(mobSer.validateName(enm))
			   {
					pp.setCustName(enm);
			
				System.out.println("Enter mailid: ");
				String mailid=sc.next();
				if(mobSer.validateMailId(mailid))
				{				
					pp.setMailId(mailid);
					
					System.out.println("Enter phone No: ");
					String phoneNo=sc.next();
					if(mobSer.validatePhoneNo(phoneNo))
					{						
						pp.setPhoneNo(phoneNo);
						
						System.out.println("Enter mobile id: ");
						int mobid=sc.nextInt();
						ArrayList<Mobile> mobList=mobSer.getAllMob();
						
						if(mobSer.validateMobid(mobList, mobid))
						{		
							pp.setMobileId(mobid);
							
							int dataAdded = mobSer.addPurchase(pp);
						System.out.println("Purchase details added: " +dataAdded);
						UpdateMobDetails(mobid);
							
						}
					 }
				  }
			   }
				
				
			}
			else
			{
				throw new MobileException("Invalid Quantity");
			}
		}
		catch (MobileException e) 
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	
	}
}
