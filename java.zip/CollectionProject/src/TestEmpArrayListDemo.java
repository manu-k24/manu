import java.util.*;
public class TestEmpArrayListDemo 
{

	public static void main(String[] args)
	{
		ArrayList<Emp> empList=new ArrayList<Emp>();
		
		Emp e1=new Emp(111,"Ronak",4000.0f);
		Emp e2=new Emp(112,"Sheetal",2000.0f);
		Emp e3=new Emp(113,"John",5000.0f);
		Emp e4=new Emp(114,"Nick",5000.0f);
		
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		
		System.out.println("*******Without Iterator********");
		System.out.println(empList);
		System.out.println("*******With Iterator********");
		Iterator<Emp> empListIt=empList.iterator();
		while(empListIt.hasNext())
		{
			Emp tempEmp=empListIt.next();
			System.out.println("Id : "+tempEmp.getEmpId());      //specific format
			System.out.println("Name : "+tempEmp.getEmpName());
			System.out.println("Salary : "+tempEmp.getEmpSal());
			System.out.println("_________________");
			//System.out.println(":"+tempEmp);            default format
		}
		

	}

}
