
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class TestDateDemo 
{

	public static void main(String[] args)
	{
		//LocalDateTime today=LocalDateTime.now();
		LocalDate today=LocalDate.now();
		System.out.println("Todays's Date: "+today);
		System.out.println("*************************");
		
		LocalDate myDOJ=LocalDate.of(2017, 12, 13);       //prints DOJ in basic format
		System.out.println("My DOJ is: "+myDOJ);
		System.out.println("*************************");
		
		String ronakDOJ="13-Dec-2017";
		DateTimeFormatter myFormat=DateTimeFormatter.ofPattern("dd-MMM-yyyy");   //MMM should be caps	
		LocalDate ronalDOJ=LocalDate.parse(ronakDOJ, myFormat);
		System.out.println("Ronak DOJ="+ronalDOJ);
		System.out.println("*************************");
		
		DateTimeFormatter secondFormat=DateTimeFormatter.ofPattern("yyyy-MMM-dd");  //give the pattern to be formatted in .ofPattern()
		String urDOJ=ronalDOJ.format(secondFormat);
		System.out.println("......."+urDOJ);
		System.out.println("*************************");
		
		//to find difference 
		System.out.println("Difference");
		Period period=Period.between(myDOJ, today);
		int years=period.getYears();
		int month=period.getMonths();
		int day=period.getDays();
		
		System.out.println("My Experience in CG is:\nYears: "+years+"\nMonths: "+month+"\nDays: "+day);
		
	}

}
