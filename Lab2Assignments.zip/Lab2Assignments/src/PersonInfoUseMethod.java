
public class PersonInfoUseMethod 
{

	public static void main(String[] args) 
	{
		Person p1=new Person();
		Person p2=new Person("9026152351");
		p1.setFirstName("Manali");
		p1.setLastName("Kadam");
		p1.setAge(22);
		
		  
		    System.out.println("Person Details:");
		    System.out.println("______________________");
			System.out.println("First Name: "+p1.getFirstName());
			System.out.println("Last Name: "+p1.getLastName());
			System.out.println("Age: "+p1.getAge());
			System.out.println("Mobile number: "+p2.mobNo);
		   
		
		
	

	}

}
