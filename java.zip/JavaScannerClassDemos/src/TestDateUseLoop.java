import java.util.Scanner;


public class TestDateUseLoop 
{

	public static void main(String[] args) 
	{
		Scanner sc=new  Scanner(System.in);
		 
		for(int i=0;i<3;i++)
		{
			System.out.println("Enter ur Name: ");
			String name=sc.next();
			
			System.out.println("Enter Day: ");
			int dayOfDOJ=sc.nextInt();
			
			System.out.println("Enter Month: ");
			int monOfDOJ=sc.nextInt();
			
			System.out.println("Enter Year: ");
			int yearOfDOJ=sc.nextInt();
			
			Date yourDOJ=new Date(dayOfDOJ, monOfDOJ, yearOfDOJ);
			System.out.println( name+"'s date of joining is: "
					+yourDOJ.dispDate());

			
		}
			
	}

}
