package com.cg.gamecity.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.cg.gamecity.DBUtil.DBUtil;
import com.cg.gamecity.dto.Games;
import com.cg.gamecity.dto.User;
import com.cg.gamecity.exception.GamecityException;

public class GameCityDaoImpl implements GameCityDao
{
	Connection conn;
	@Override
	public List<Games> getAllGames() throws GamecityException 
	{
		List<Games> glist= new ArrayList<>();
		Statement st;
		conn=DBUtil.getConnection();
		try
		{
		st=conn.createStatement();
		ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_ONLINEGAMES);
		while(rst.next())
		{
			Games g = new Games();
			g.setGameName(rst.getString("name"));
			g.setGameAmt(rst.getDouble("amount"));
			glist.add(g);
		}
		}
		catch(SQLException e)
		{
			throw new GamecityException("Problem in fetching game list"+e.getMessage());
		}
		return glist;
	}
	
	private long generateUserId() throws GamecityException
	{
		long uid=0;
		conn = DBUtil.getConnection();
		try
		{
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rst.next();
			uid=rst.getLong(1);
		}
		catch(SQLException e)
		{
			throw new GamecityException("Problem in generating user id:"+e.getMessage());
		}
		return uid;
	}
	
	@Override
	public long insertUsers(User user) throws GamecityException 
	{
		conn=DBUtil.getConnection();
		user.setUserId(generateUserId());
		try 
		{
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1, user.getUserId());
			pst.setString(2, user.getUserName());
			pst.setString(3, user.getUserAddress());
			pst.setDouble(4, user.getCardAmt());
			System.out.println(user.getCardAmt());
			pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			throw new GamecityException("Problem in inserting details"+e.getMessage());
		}
		return user.getUserId();
	}
}
