
public class TestPersonDemo {

	public static void main(String[] args) {
		Person p1=new Person("Amol","HDF45H",22);
		Person p2=new Person("Ani","clF2H",22);
		Person p3=new Person("Amol","HDF45H",22);
		
		System.out.println(p1);  //toString belongs to object class and person belongs to obj class
		System.out.println(p2);
		System.out.println(p3);
		
		if(p1.equals(p3))         //add this part for equals fn demo
		{
			System.out.println(" Same"); 
		}
		else
		{
			System.out.println("Not Same"); 
		}
		
		Integer i1=new Integer(20);
		Integer i2=new Integer(30);
		Integer i3=new Integer(20);
		
		System.out.println("i1= "+i1);
		System.out.println("i2= "+i2);
		System.out.println("i3= "+i3);
		
		if(i1.equals(i3))
		{
			System.out.println(" Same"); 
		}
		else
		{
			System.out.println("Not Same"); 
		}
		
		System.out.println("HashCode of p1: "+p1.hashCode()); //hashcodes of p-they generate int values
		System.out.println("HashCode of p2: "+p2.hashCode());
		System.out.println("HashCode of p3: "+p3.hashCode());
		

		System.out.println("HashCode of i1: "+i1.hashCode()); //hashcodes of i
		System.out.println("HashCode of i2: "+i2.hashCode());
		System.out.println("HashCode of i3: "+i3.hashCode());
	}

}
