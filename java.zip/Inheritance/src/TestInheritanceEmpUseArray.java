import java.util.Scanner;


public class TestInheritanceEmpUseArray 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("How many employees?");
		int empCount=sc.nextInt();
		Employee empArr[]=new Employee[empCount];
		
		int eId=0;
		String enm=null;
		float esl=0.0F;
		int noOfHours=0;
		int ratePerHour;
		
		for(int i=0;i<empArr.length;i++)
		{
			System.out.println("Enter the empId: ");
			eId=sc.nextInt();
			System.out.println("Enter the empName: ");
			enm=sc.next();
			System.out.println("Enter the empSalary: ");
			esl=sc.nextFloat();
			System.out.println("Enter what type of Employee u want: "+
			"1. Emp\t "+
			"2. Wage Emp\t"+ 
			"3. Sales Manager\n");
			System.out.println("Enter the choice:");
			int choice =sc.nextInt();
			
			switch (choice)
			{
				case 1: empArr[i]=new Employee(eId,enm,esl);
						break;
			
				case 2: System.out.println("Enter the no of hours u worked:");
						noOfHours=sc.nextInt();
						System.out.println("Enter the rate per hour:");
						ratePerHour=sc.nextInt();
						empArr[i]=new WageEmp(eId,enm,esl,noOfHours,ratePerHour);
						break;
					
				default:System.out.println("Enter the no of hours u worked:");
						noOfHours=sc.nextInt();
						System.out.println("Enter the rate per hour:");
						ratePerHour=sc.nextInt();
						System.out.println("Enter the sales: ");
						int sale=sc.nextInt();
						System.out.println("Enter the commision: ");
						float comm=sc.nextFloat();
						empArr[i]=new SalesManager(eId,enm,esl,noOfHours,ratePerHour,sale,comm);
						
						System.out.println("*****************************************");
						for(int j=0;j<empArr.length;j++)
						{
							if(empArr[j] instanceof SalesManager)
							{
								System.out.println("SalesManager: "+empArr[j].dispEmpInfo()+
													"\nMonthly Basic Salary: "+empArr[j].calcEmpBasicSal()+
													"\nAnnual Salary: "+empArr[j].calcEmpAnnSal());
							}
							else if(empArr[j] instanceof WageEmp)
							{
								System.out.println(	"WageEmp: "+empArr[j].dispEmpInfo()+
													"\nMonthly Basic Salary: "+empArr[j].calcEmpBasicSal()+
													"\nAnnual Salary: "+empArr[j].calcEmpAnnSal());
							}
							else
							{
								System.out.println(	"Employee: "+empArr[j].dispEmpInfo()+
													"\nMonthly Basic Salary: "+empArr[j].calcEmpBasicSal()+
													"\nAnnual Salary: "+empArr[j].calcEmpAnnSal());
							}
						}
					
			}
		}
		
		
		

	}

}
