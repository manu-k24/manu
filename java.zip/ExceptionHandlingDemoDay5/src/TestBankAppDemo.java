import java.util.Scanner;

public class TestBankAppDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int currBalance=60000;
		System.out.println("Enter the withdraw amount: ");
		int withdrawAmt=sc.nextInt();
		if(withdrawAmt<currBalance)
		{
			System.out.println("Ok u have sufficient balance u can withdraw");
		}
		else
		{
			try 
			{
				throw new LowBalanceException
				("Please check balance of ur account");
			} 
			catch (LowBalanceException e) 
			{
				System.out.println("Insufficient balance in ur account"+e.getMessage());
				e.printStackTrace();
			}
	
		}

	}

}
