package com.cg.user.dao;

import java.sql.SQLException;

import com.cg.user.dto.Login;

public interface LoginDao 
{
	public Login getUserByUnm(String unm) throws SQLException;
}
