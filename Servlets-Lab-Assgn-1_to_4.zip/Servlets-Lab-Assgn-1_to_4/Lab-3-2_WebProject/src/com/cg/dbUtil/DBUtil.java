package com.cg.dbUtil;

import java.sql.*;
import java.sql.DriverManager;

public class DBUtil 
{
	public static Connection getCon() throws SQLException
	{
		Connection con = null;
		con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		return con;
	}
}
