import java.util.*;


class TestEmpTreeSetDemo 
{

	public static void main(String[] args) 
	{
		TreeSet<Emp> empSet=new TreeSet<Emp>();
		
		Emp e1=new Emp(111,"Ronak",4000.0f);
		Emp e2=new Emp(112,"Sheetal",2000.0f);
		Emp e3=new Emp(113,"John",5000.0f);
		Emp e4=new Emp(114,"Nick",5000.0f);
		Emp e5=new Emp(111,"Ronak",4000.0f);
		
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		empSet.add(e5);
		
		for(Emp tempEmp:empSet)  
		{
			System.out.println(tempEmp);       //Enhanced for loop
		}


	}

}

