
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class TestSerializationFor_N_Emp 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of Emps: ");
		int nums=sc.nextInt();
		
		Emp e1[]=new Emp[nums];
		
		for(int i=0;i<e1.length;i++)
		{
		System.out.println("Enter Emp Id: ");
		int empId=sc.nextInt();
		System.out.println("Enter Emp Name: ");
		String empName=sc.next();
		System.out.println("Enter Emp Salary: ");
		float empSal=sc.nextFloat();
		e1[i]=new Emp(empId,empName,empSal);
		}
		
		FileOutputStream fos;
		ObjectOutputStream  oos;
		
		int j;
		try
		{
			fos=new FileOutputStream("N_EmpData.obj");
			oos=new ObjectOutputStream(fos);
			for(j=0;j<nums;j++)
			{
			oos.writeObject(e1[j]);
			}
			System.out.println("Emp object is written in a file");
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		

	}

}
