import java.util.*;


public class TestIntHashSetDemo 
{

	public static void main(String[] args) 
	{
		HashSet<Integer> intSet=new HashSet<Integer>();
		
		Integer i1=new Integer(10);
		Integer i2=new Integer(20);
		Integer i3=new Integer(20);
		Integer i4=new Integer(50);
		
		intSet.add(i1);
		intSet.add(i2);
		intSet.add(i3);
		intSet.add(i4);
		
		System.out.println("*******Without Iterator********");
		System.out.println(intSet);
		
	}

}
