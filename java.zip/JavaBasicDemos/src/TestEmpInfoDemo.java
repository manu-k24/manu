
public class TestEmpInfoDemo 
{

	public static void main(String[] args) 
	{
		Employee e1=new Employee(112018,"Vaishali Srivastava",1000.0F,'F');
		
		Employee e2=new Employee(145236,"Anjulata Tembhare",4000.0F,'F');
		
		Employee e3=new Employee(123565,"Rahul Yadav",5000.0F,'M');
		
		System.out.println("Emp Info:"+e1.dispEmpDetails()); 
		System.out.println("Emp Info:"+e2.dispEmpDetails()); 
		System.out.println("Emp Info:"+e3.dispEmpDetails()); 


	}

}
