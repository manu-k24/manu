
public class SyrupInfo extends Medicine
{
	private int perDayIntake;
	private String typeOfSyrup;
	private String msg="Shake well before use";
	
	public SyrupInfo(int price, String mediName, String compName, Date expDate,
			int perDayIntake, String typeOfSyrup,String msg) 
	{
		super(price, mediName, compName, expDate);
		this.perDayIntake = perDayIntake;
		this.typeOfSyrup = typeOfSyrup;
		this.msg=msg;
	}

	public String dispMediInfo() 
	{
		return "SyrupInfo [perDayIntake=" + perDayIntake + ", typeOfSyrup="
				+ typeOfSyrup + ", msg=" + msg + ", expDate=" + expDate.dispDate() + "]";
	}
	
	
	
	
	
	
}
