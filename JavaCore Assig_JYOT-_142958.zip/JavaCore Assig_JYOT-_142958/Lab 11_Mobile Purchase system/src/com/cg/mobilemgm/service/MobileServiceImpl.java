package com.cg.mobilemgm.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.dao.MobileDao;
import com.cg.mobilemgm.dao.MobileDaoImpl;
import com.cg.mobilemgm.exception.MobileException;

public class MobileServiceImpl implements MobileService
{
	MobileDao mobdao=null;
	public MobileServiceImpl()
	{
		mobdao= new MobileDaoImpl();
	}

	@Override
	public int addMobPur(PurchaseDetails pur,Mobiles mob) throws MobileException {
		return mobdao.addMobPur(pur,mob);
	}

	@Override
	public long generateMobId() throws MobileException {
		return mobdao.getPurchaseId();
	}
	@Override
	public boolean validateDigit(String phnNo) throws MobileException
	{
		String numPattern="[7-9][0-9]{9}";
		if(Pattern.matches(numPattern, phnNo))
		{
			return true;
		}
		else
		{
			throw new MobileException("Please Entered Valid 10 digit Mobile Number(Should be "
					+ "Start with 7,8 or 9)");
		}

	}
	//////////////////////////////
	@Override
	public boolean validateName(String cusName) throws MobileException
	{
		String numPattern="[A-Z][a-z]{2,19}";
		if(Pattern.matches(numPattern, cusName))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only charcters allowed...First letter should be Capital");
		}

	}
	////////////////////
	@Override
	public boolean validateEmail(String email) throws MobileException
	{
		String numPattern="^(.+)@(.+)$";
		//"^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
		if(Pattern.matches(numPattern, email))
		{
			return true;
		}
		else
		{
			throw new MobileException("Email ID Invaid....Plz entered Email ID like jyoti@gamil.com");
		}

	}

	@Override
	public boolean validateMobileId(int mobId) throws MobileException 
	{
		String numPattern="[1][0-9]{3}";
		int flag=0;
		if(Pattern.matches(numPattern, new Integer(mobId).toString()))
		{
			ArrayList<Integer> mobIdList=mobdao.getAllMobileId();
			for(int tempmobIdList:mobIdList)
			{
				if(mobId==tempmobIdList)
				{
					flag=1;
				}
			}
		}
		if(flag==1)
		{
			return true;
		}

		else{

			throw new MobileException("Invalid Mobile Id....Min 4 digits allowed");

		}

	}
/////////////////////////////////////////////
	@Override
	public int validateMobileQuan(Mobiles mob) throws MobileException
	{
		return mobdao.getMobQuan(mob);
	}
	////////////////////////////////////////
	@Override
	public ArrayList<Mobiles> getAllMob() throws MobileException {

		return mobdao.getAllMob();
	}

	@Override
	public int deleteMobDetail(int mobId)throws MobileException
	{
		System.out.println(" in service**************************");
		return mobdao.deleteMobDetail(mobId);
	}

	@Override
	public ArrayList<Mobiles> searchMob(float maxRange, float minRange) 
			throws MobileException {		
		return mobdao.searchMob(maxRange, minRange);
	}
	
	@Override
	public int updateMobile(Mobiles mob) throws MobileException{
		return mobdao.updateMobile(mob);
	}
}
