
public class Employee 
{
	private int empId;
	private String empName;
	private float empSal;
	private char empGender;
	Date empDOJ;
	
	public Employee()
	{
	empId=0;
	empName="Unknown";
	empSal=0.0F;
	empGender=' ';
	empDOJ=new Date();
	}

	public Employee(int empId, String empName, float empSal, char empGender,
			Date empDOJ) 
	{
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empGender = empGender;
		this.empDOJ = empDOJ;
	}
	
	public String  dispEmpDetails() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + ", empGender=" + empGender
				+ ", empDOJ=" + empDOJ.dispDate() + "]";
	}
	
	
	
}
