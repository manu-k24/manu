
import java.sql.*;
import java.util.*;


public class TestEmpSwitchDemo 
{

	public static void main(String[] args) 
	{
		Connection con = null;
	    PreparedStatement pst;
	    Statement st=null;
	    ResultSet rs=null;
	    Scanner sc=null;
	    
	    try
	    {
	    	sc=new Scanner(System.in);
	    	System.out.println("1. Select\t 2. Insert\t 3. Delete\t 4. Update");
	    	System.out.println("Enter a choice: ");
	    	int choice=sc.nextInt();
	    	
	    	Class.forName("oracle.jdbc.driver.OracleDriver");        //step3a
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");     //step4   
			 
			switch(choice)
			{
			case 1: //select Query
					System.out.println("Enter Id: ");
					int empId=sc.nextInt();
					String selQuery="SELECT empId,ename,empSal from Emp_142966 where empid=(?)";
					pst=con.prepareStatement(selQuery);     //gives statement object
					System.out.println("ID \t NAME \t SALARY");
					pst.setInt(1, empId);
					rs=pst.executeQuery();
					while(rs.next())
					{
						System.out.println(rs.getInt("empId")+"\t"+rs.getString("ename")+"\t"+rs.getInt("empSal"));
					}
					break;
					
			case 2: //Insert Query
					String insertQry = "insert into emp_142966(empId,ename,empsal) VALUES(?,?,?)";
				    pst=con.prepareStatement(insertQry);
				    int dataAdded;
			          
				    System.out.println("Enter the number: ");
				    int n=sc.nextInt();
				    for(int i=0;i<n;i++)
				    {
				       System.out.println("Enter Id: ");
				      empId=sc.nextInt();
				       System.out.println("Enter Name: ");
				       String ename=sc.next();
				       System.out.println("Enter Salary: ");
				       float empSal=sc.nextFloat();
				          
				       pst.setInt(1, empId);
				       pst.setString(2, ename);
				       pst.setFloat(3, empSal);
				       dataAdded=pst.executeUpdate();
				       System.out.println("Data is added...."+dataAdded); 
				      }
				    break;
				
			case 3: //Delete Query
					String deleteQry = "delete from emp_142966 where empId=6895";
				    pst=con.prepareStatement(deleteQry);
				    int dataDeleted;
				    dataDeleted=pst.executeUpdate();
				    System.out.println("Data is added...."+dataDeleted);
		      		break;
					
			case 4: //Update Query
					String updateQry = "Update emp_142966 set empsal=(empsal+10000) where empsal<50000";
				    pst=con.prepareStatement(updateQry);
				    int dataUpdated;
				    dataUpdated=pst.executeUpdate();
				    System.out.println("Data is added...."+dataUpdated);
					break;
			
			default:System.out.println("Invalid choice");
				
			}
		}
	    catch (Exception e)
	    {
			e.printStackTrace();
		}
	}

}
