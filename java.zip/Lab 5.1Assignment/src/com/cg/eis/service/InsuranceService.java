package com.cg.eis.service;

public class InsuranceService implements EmployeeService{
	//private String scheme;;
	private double eSal; 
	private String eDesig;
	
	public InsuranceService() {
	
	}

	public InsuranceService( double eSalary, String eDesignation) {
		
		this.eSal = eSalary;
		this.eDesig = eDesignation;
	}

	public double geteSalary() {
		return eSal;
	}

	public void seteSalary(double eSalary) {
		this.eSal = eSalary;
	}

	public String geteDesignation() {
		return eDesig;
	}

	public void seteDesignation(String eDesignation) {
		this.eDesig = eDesignation;
	}

	@Override
	public String getInsuranceScheme() 
	{
		
		if(eSal>5000 && eSal<20000 && eDesig.compareTo("System Associate")==0)
		{
			return "Scheme C";
			
		}
				else if(eSal>=20000 && eSal<40000 && eDesig.compareTo("Programmer")==0)
		{
			return "Scheme B";
			
		}
		else if(eSal>=40000 && eDesig.compareTo("Manager")==0)
		{
			return "Scheme A";
			
		}
		else 
		{
			return "No Scheme";
		}	 
		
	}

}
