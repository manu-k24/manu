package com.cg.gamecity.service;
import java.util.List;
import com.cg.gamecity.dto.Games;
import com.cg.gamecity.dto.User;
import com.cg.gamecity.exception.GamecityException;

public interface GameCityService 
{
	List<Games> getAllGames() throws GamecityException;
	long insertUsers(User user) throws GamecityException;
}
