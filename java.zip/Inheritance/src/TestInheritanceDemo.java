
public class TestInheritanceDemo 
{

	public static void main(String[] args) 
	{
		Employee vaishali=new Employee(111,"Vaishali",20000.0F);
		Employee babita=new WageEmp(112,"Babita",5000.0F,400,5);
		Employee manan=new SalesManager(116,"manan",6000.0F,50,20,2000.0F,0.2F);
		
		System.out.println("Employee Info: "+ vaishali.dispEmpInfo());		
		System.out.println("Emp Monthly Sal: "+ vaishali.calcEmpBasicSal());
		System.out.println("Emp Annual Sal: "+ vaishali.calcEmpAnnSal());
		
		System.out.println();
		System.out.println("Employee Info: "+ babita.dispEmpInfo());		
		System.out.println("Emp Monthly Sal: "+ babita.calcEmpBasicSal());
		System.out.println("Emp Annual Sal: "+ babita.calcEmpAnnSal());
		
		System.out.println();		
		System.out.println("Employee Info: "+ manan.dispEmpInfo());		
		System.out.println("Emp Monthly Sal: "+ manan.calcEmpBasicSal());
		System.out.println("Emp Annual Sal: "+ manan.calcEmpAnnSal());
	}

}
