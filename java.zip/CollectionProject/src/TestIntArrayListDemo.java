import java.util.*;


public class TestIntArrayListDemo 
{
	public static void main(String[] args) 
	{
		ArrayList<Integer> intList=new ArrayList<Integer>();
		Integer i1=new Integer(10);
		Integer i2=new Integer(20);
		//String str3=new String("jhgff");
		Integer i3=new Integer(40);
		Integer i4=new Integer(50);
		
		intList.add(i1);
		intList.add(i2);
		//intList.add(str3);
		intList.add(i3);
		intList.add(i4);
		System.out.println("*******Without Iterator********");
		System.out.println(intList);
		System.out.println("*******With Iterator********");
		Iterator<Integer> it=intList.iterator();
		while(it.hasNext())
		{
			//Integer tempEntry=(Integer)it.next();
			//System.out.println(" : "+it.next());
			int tempEntry=it.next();
			System.out.println(" : "+tempEntry);
		}
		

	}

}
