package com.cg.recruitapp.service;

import com.cg.recruitapp.bean.ContactBook;
import com.cg.recruitapp.exception.ContactBookException;

public interface ContactBookService
{
	public int addEnquiry(ContactBook contact) throws ContactBookException;
	public int generateEnquiryId() throws ContactBookException;
	public ContactBook getEnquiryDetails(int EnquiryId) throws ContactBookException;
	
	public boolean validateFirstName(String fName) throws ContactBookException;
	public boolean validateLastName(String lName) throws ContactBookException;
	public boolean validatePrefLocation(String pLocation) throws ContactBookException;
	public boolean validateDomain(String pDomain) throws ContactBookException;
	public boolean validateContactNo(String contactNo) throws ContactBookException;
}
