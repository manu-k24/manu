import static java.lang.Math.*;
class Parent
{
	public void print()                       //parent has 2 functions
	{                                         //1.print
		System.out.println("Parent: ");
	}
	/*public int add(int a,int b)
	{
		int sum=0;
		sum=sum+a+b;
		return sum;
	}*/
	public int add(int ... numbers)            //2.add
	{
		int sum=0;
		for(int j=0;j<numbers.length;j++)
		{
		sum=sum+numbers[j];
		}
		return sum;
		
	}
}
class Child extends Parent                    //when child extends parent it can use both functions
{                                             //of parent class
	@Override                                 //we override print method in child class 
	public void print()                       //to print "child:" and not "parent:" 
	{
		System.out.println("Child: ");
	}
}
public class TestJava5FeaturesDemo 
{

	public static void main(String[] args)
	{
		System.out.println("PI= "+PI);
		System.out.println("Cube of 2= "+pow(2,3));
		
		Parent pp=new Parent();
		//System.out.println("Addition is: "+pp.add(9, 80));
		System.out.println("Addition of 2 is: "+
		pp.add(9, 80));
		System.out.println("Addition of 4 is: "+
		pp.add(9,2,5,6));
		System.out.println("Addition of 3 is: "+
		pp.add(9,2,6));
		
		//enhance for loop
		System.out.println("Enhance for loop");
		int marks[]=new int[3];
		marks[0]=90;
		marks[1]=80;
		marks[2]=70;
		String cityList[]={"Mumbai","Pune","Bangalore"};
		
		for(int tempMarks:marks)
		{
			System.out.println(" "+tempMarks);
		}
		for(String city:cityList)
		{
			System.out.println(" "+city);
		}
	}

}
