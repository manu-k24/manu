import java.util.Scanner;
public class TestDateUseLoop1 
{

	public static void main(String[] args) 
	{
		Scanner sc=new  Scanner(System.in);
		Date allDojs[]=new Date[3];
		//String name;    
		String name[]=new String[3];
		int dayOfDOJ=0,monOfDOJ=0,yearOfDOJ=0;
		
		for(int i=0;i<allDojs.length;i++)
		{
			System.out.println("Enter ur Name: ");
			name[i]=sc.next();
			
			System.out.println("Enter Day: ");
			dayOfDOJ=sc.nextInt();
			
			System.out.println("Enter Month: ");
			monOfDOJ=sc.nextInt();
			
			System.out.println("Enter Year: ");
			yearOfDOJ=sc.nextInt();
			
			allDojs[i]=new Date(dayOfDOJ,monOfDOJ,yearOfDOJ);
		}
			
			for(int j=0;j<allDojs.length;j++)
			{
				System.out.println(" DOJ: "+allDojs[j].dispDate());
			}
		
		
		
	}

}
