
public class Medicine 
{
	private int price;
	private String mediName;
	private String compName;
	Date expDate;
	
	public Medicine(int price, String mediName, String compName, Date expDate)
	{
		super();
		this.price = price;
		this.mediName = mediName;
		this.compName = compName;
		this.expDate = expDate;
	}

	public String dispMediInfo()
	{
		return "Medicine [price=" + price + ", mediName=" + mediName
				+ ", compName=" + compName + ", expDate=" + expDate + "]";
	}
	
	
	
}
