package com.cg.recruitapp.ui;

import java.util.ArrayList;
import java.util.Scanner;




import com.cg.recruitapp.bean.ContactBook;
import com.cg.recruitapp.exception.ContactBookException;
import com.cg.recruitapp.service.ContactBookService;
import com.cg.recruitapp.service.ContactBookServiceImpl;

public class Client 
{
	static Scanner sc=null;
	static ContactBookService contactSer=null;
		
	public static void main(String[] args)
	{
		contactSer=new ContactBookServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("*****************Global Recruitments******************");
			System.out.println("Choose an operation");
			System.out.println("1. Enter Enquiry Details\n"
							  +"2. View Enquiry Details on Id\n"		
							  +"3. Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:	insertEnquiryDetails();	
					break;
			case 2:	getenquiryDetails();
					break;
			case 3:	System.exit(0);
			
					System.out.println("Thank you selecting us!!");
					break;	
			
			default: System.out.println("Invalid Choice");
			}
			
		}
	}
//*********************************main ends here*************************************
	private static void getenquiryDetails()
	{
		
		try 
		{
			System.out.println("Enter Enquiry Id: ");
			int enquiryId=sc.nextInt();
			ContactBook contact;
			contact = contactSer.getEnquiryDetails(enquiryId);
			System.out.println("First Name: "+contact.getfName());
			System.out.println("Last Name: "+contact.getlName());
			System.out.println("Contact No: "+contact.getContactNo());
			System.out.println("Preffered Domain: "+contact.getpDomain());
			System.out.println("Preffered Location: "+contact.getpLocation());
		} 
		catch (ContactBookException e) 
		{
			e.printStackTrace();
		}		
		
	}
//*****************************************************************************************
	private static void insertEnquiryDetails() 
	{
		ContactBook contact=new ContactBook();
		
		try {
			System.out.println("Enter First Name: ");
			String fName=sc.next();
			if(contactSer.validateFirstName(fName))
			{
				contact.setfName(fName);	
				System.out.println("Enter Last Name: ");
				String lName=sc.next();
				 
			    if(contactSer.validateLastName(lName))
			    {				
					contact.setlName(lName);
					System.out.println("Enter the Contact number: ");
					String contactNo=sc.next();
					
					if(contactSer.validateContactNo(contactNo))
					{
						contact.setContactNo(contactNo);
						System.out.println("Enter the Domain: ");
						String pDomain=sc.next();
						
						if(contactSer.validatePrefLocation(pDomain))
						{
							contact.setpDomain(pDomain);			
							System.out.println("Enter Preffered Location: ");
							String pLocation=sc.next();
							
							if(contactSer.validatePrefLocation(pLocation))
							{						
								contact.setpLocation(pLocation);
									
								int dataAdded = contactSer.addEnquiry(contact);
								System.out.println("Enquiry details added: " +dataAdded);
							}
						}
					}
			    }
			}
			else
			{
				throw new ContactBookException("Invalid Quantity");
			}
		} 
		catch (ContactBookException e) 
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
}
