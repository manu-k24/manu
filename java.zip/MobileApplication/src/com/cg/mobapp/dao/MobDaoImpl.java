package com.cg.mobapp.dao;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobapp.bean.Mobile;
import com.cg.mobapp.exception.MobileException;
import com.cg.mobapp.util.DBUtil;

public class MobDaoImpl implements MobDao
{
	
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int dataAdded=0;
	int dataDeleted=0;
	int dataUpdated=0;
	int dataSearched=0;
	Scanner sc=new Scanner(System.in);
	
	
	
	@Override
	public int addMob(Mobile mob) throws MobileException 
	{
		String insertQry="Insert into purchasedetails(mobileid,name,price,quantity) values(?,?,?,?)";   
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,mob.getMobId());
			pst.setString(2,mob.getMobName());
			pst.setFloat(3,mob.getPrice());
			pst.setInt(4,mob.getQuantity());
			dataAdded = pst.executeUpdate();	
			
		} 
		catch (Exception e)
		{
			
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		
		return dataAdded;
	}


	@Override
	public ArrayList<Mobile> getAllMob() throws MobileException
	{
		ArrayList<Mobile> mobList=new ArrayList<Mobile>();
		String selectQry="SELECT * FROM mobiles";
		Mobile ee;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			
			while(rs.next())
			{
				ee=new Mobile (rs.getInt("mobileId"),rs.getString("Name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(ee);
			}
		} 
		catch (Exception e)
		{
			throw new MobileException(e.getMessage()); 
		} 		
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (Exception e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		
		return mobList;
		
	}


	@Override
	public int delMob(int mobid) throws MobileException
	{

		String deleteQry="Delete from mobiles where mobileid=?";
		
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteQry);
			
			pst.setInt(1, mobid);
			dataDeleted=pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage()); 
		}	
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataDeleted;
		
	}


	@Override
	public int UpdateMobQty(int mobid) throws MobileException
	{
		String updateQry = "Update mobiles set quantity=quantity-1 where mobileid=(?)";		
        try {
        	con=DBUtil.getCon();
			pst=con.prepareStatement(updateQry);
			pst.setInt(1, mobid);
		    dataUpdated=pst.executeUpdate();
		    System.out.println("Data is updated...."+dataUpdated);
		 
		} catch (Exception e) 
        {			
			throw new MobileException(e.getMessage()); 
		}
        finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
        return dataUpdated;
       
	}


	@Override
	public ArrayList<Mobile> searchMobile(float min, float max) throws MobileException 
	{
		ArrayList<Mobile> mobList=new ArrayList<Mobile>();
		String searchQry="SELECT * FROM mobiles WHERE price > ? AND price < ?";
		Mobile ee=null;
		
		 try {
	        	con=DBUtil.getCon();
				pst=con.prepareStatement(searchQry);
				pst.setFloat(1, min);
				pst.setFloat(2, max);
			    rs=pst.executeQuery();
			    
			    while(rs.next())
			    {
			    	ee=new Mobile (rs.getInt("mobileId"),rs.getString("Name"),rs.getFloat("price"),rs.getInt("quantity"));
					mobList.add(ee);
			    }
			 
			} catch (Exception e) 
	        {			
				throw new MobileException(e.getMessage()); 
			}
	        finally
			{
				try 
				{
					rs.close();
					pst.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					throw new MobileException(e.getMessage());
				}
			}
	        return mobList;
	}


	
}
