import java.sql.*;


public class TestEmpSelectDemo 
{

	public static void main(String[] args) 
	{
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try 
		{
			//Load oracle type4 driver in memory
			Class.forName("oracle.jdbc.driver.OracleDriver");        //step3a
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");     //step4
			st=con.createStatement();     //gives statement object
			String selQuery="SELECT empId,ename,empSal from Emp_142966";
			rs=st.executeQuery(selQuery);
			
			//rs.next();
			System.out.println("ID \t NAME \t SALARY");
			while(rs.next())
			{
				System.out.println(rs.getInt("empId")+"\t"+rs.getString("ename")+"\t"+rs.getInt("empSal"));
			}
		} 
		catch (Exception e)    //generic exception catch block
		{
			e.printStackTrace();
		}

	}

}
