import java.util.Scanner;


public class TestEmpAggregatnForN
{

	public static void main(String[] args)
	{
		Scanner sc=new  Scanner(System.in);
		int noOfEmps;
		System.out.println("Enter Number of Employees: ");
		noOfEmps=sc.nextInt();
		Employee Emps[]=new Employee[noOfEmps];
		
		int empId;
		String empName;
		float empSal;
		char empGender;
		int day;
		int mon;
		int year;
		Date empDOJ=null;
		
		for(int i=0;i<Emps.length;i++)
		{
			System.out.println("Enter Employee Id: ");
			empId=sc.nextInt();
			
			System.out.println("Enter Employee Name: ");
			empName=sc.next();
			
			System.out.println("Enter Employee salary: ");
			empSal=sc.nextFloat();
			
			System.out.println("Enter the gender: ");
			empGender=sc.next().charAt(0);
			
			System.out.println("Enter the day: ");
			day=sc.nextInt();
			
			System.out.println("Enter the month: ");
			mon=sc.nextInt();
			
			System.out.println("Enter the year: ");
			year=sc.nextInt();
			
			empDOJ=new Date(day,mon,year);
			Emps[i]=new Employee(empId,empName,empSal,empGender,empDOJ);
		}

	}

}
