package com.cg.mpa.junit;

public class TestMobilePurchase 
{

}
