
import java.util.HashMap;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Iterator;



public class TestHashMapDemo 
{

	public static void main(String[] args)
	{
		HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
		mobileDirectory.put(9026853221L, "Shilpa");
		mobileDirectory.put(8026853221L, "Shushma");
		mobileDirectory.put(5026853221L, "Shiya");
		mobileDirectory.put(7026853221L, "Shile");
		mobileDirectory.put(9026853221L, "Shilpa");
		
		Set<Entry<Long,String>> setIt=mobileDirectory.entrySet();
		Iterator<Entry<Long,String>>mobIt=setIt.iterator();
		while(mobIt.hasNext())
		{
			Entry<Long,String> dirEntry=mobIt.next();
			System.out.println("Mobile: "+dirEntry.getKey());//+"Name: "+dirEntry.getValue());    
			
		}
		
	}

}
