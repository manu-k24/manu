
public class TestEmpAggregationDemo
{

	public static void main(String[] args) 
	{
		Date manaDOJ=new Date(13,12,2017);
		Date vaishaDOJ=new Date(03,02,2015);
		Employee manali=new Employee(1234,"Manali",25000.F,'f',manaDOJ);
		Employee vaishali=new Employee(1234,"Vaishali",35000.F,'f',vaishaDOJ);
		
		System.out.println(manali.dispEmpDetails());
		System.out.println(vaishali.dispEmpDetails());

	}

}
