package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SuccessServlet")
public class SuccessServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
 
    public SuccessServlet() 
    {
        super();
      
    }

	public void init(ServletConfig config) throws ServletException 
	{
	
	}

	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String fname=(String) request.getAttribute("fnm");
		String lname=(String) request.getAttribute("lnm");
		String pwd=(String) request.getAttribute("pwd");
		String gender=(String) request.getAttribute("gen");
		String skillstr=(String) request.getAttribute("skill");
		String city=(String) request.getAttribute("city");
		PrintWriter out=response.getWriter();
		out.println("Entered Details are: <br/>");
		out.println("First Name: "+fname);
		out.println("<br/>Last Name:"+lname);
		out.println("<br/>Password: "+pwd);
		out.println("<br/>Gender: "+gender);
		out.println("<br/>Skill set: "+skillstr);
		out.println("<br/>City: "+city);
	}

}
