import com.cg.bat.Batch;
import com.cg.stu.Student;
public class TestStudentDemo 
{

	public static void main(String[] args) 
	{
		Batch javaBatch=new Batch("JEE_PROPEL_001","8.30 TO 6.00",
				"Anjulata Tembhare");
		Batch vnvBatch=new Batch("VNV_PT_002","8.30 TO 6.00",
				"Shilpa Bhosale");
		Batch oraAppBatch=new Batch("ORA_APP_ABridge_003","8.30 TO 6.00",
				"Scahin Naradekar");
		
		Student student1=new Student(111,"Ronak",90,javaBatch);
		Student student2=new Student(112,"Usha",65,javaBatch);
		Student student3=new Student(115,"Megha",80,vnvBatch);
		Student student4=new Student(119,"Jay",91,oraAppBatch);
		
		System.out.println(student1.dispStuInfo());
		System.out.println(student2.dispStuInfo());
		System.out.println(student3.dispStuInfo());
		System.out.println(student4.dispStuInfo());
	}

}
