package com.cg.mobapp.dao;

import java.sql.*;
import java.util.Scanner;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobapp.util.DBUtil;
import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.exception.MobileException;


public class PurchaseDaoImpl implements PurchaseDao
{
	Logger mobLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int dataAdded=0;
	Scanner sc=new Scanner(System.in);
	public PurchaseDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		mobLogger=Logger.getLogger("PurchaseDaoImpl.class");
	}
	@Override
	public int addPurchase(PurchaseDetails purchase) throws MobileException
	{
		String insertQry="INSERT INTO purchaseDetails(purchaseid,cname,mailid,phoneno,purchasedate, mobileid) VALUES(?,?,?,?,sysdate,?)";
	
	try 
	{
		con=DBUtil.getCon();
		pst=con.prepareStatement(insertQry);
        pst.setInt(1, generatePurchaseId());
        pst.setString(2, purchase.getCustName());
        pst.setString(3, purchase.getMailId());
        pst.setString(4, purchase.getPhoneNo());
        pst.setInt(5, purchase.getMobileId());
        dataAdded=pst.executeUpdate();
        mobLogger.log(Level.INFO, "Mob Inserted: "+purchase);
	}
	catch (Exception e) 
	{
		
		throw new MobileException(e.getMessage()); 
	}	
	finally
	{
		try 
		{
			pst.close();
			con.close();
		} 
		catch (SQLException e) 
		{
			mobLogger.error("This is exception:"+e.getMessage());
			throw new MobileException(e.getMessage());
		}
		
	}
	return dataAdded;
}

	@Override
	public int generatePurchaseId() throws MobileException
	{
		String qry="Select mob_seq.NEXTVAL FROM DUAL";
		int generatedVal;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			
			rs.next();
			generatedVal=rs.getInt(1);
			
		}
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());     //exception not handled
		} 
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return generatedVal;
	}
}


