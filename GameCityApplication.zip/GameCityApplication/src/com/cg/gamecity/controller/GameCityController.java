package com.cg.gamecity.controller;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.gamecity.dto.Games;
import com.cg.gamecity.dto.User;
import com.cg.gamecity.exception.GamecityException;
import com.cg.gamecity.service.GameCityService;
import com.cg.gamecity.service.GameCityServiceImpl;

@WebServlet(urlPatterns={"/buy","/play"})
public class GameCityController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url=request.getServletPath();
		String targetUrl = "";
		GameCityService gSer=new GameCityServiceImpl();
		User u=null;
		switch(url)
		{
		case "/buy":
		{
			u=new User();
			u.setUserName(request.getParameter("txtNm"));
			u.setUserAddress(request.getParameter("txtAdd"));
			double getAmt=Double.parseDouble(request.getParameter("txtAmt"))-100;
			u.setCardAmt(getAmt);
			
			try 
			{
				long id=gSer.insertUsers(u);
				HttpSession sess=request.getSession(true);
				sess.setAttribute("user", u);
				List<Games> glist=gSer.getAllGames();
				sess.setAttribute("glist",glist);
				targetUrl="Play.jsp";
			} 
			
			catch (GamecityException e1) 
			{
				request.setAttribute("error", e1.getMessage());
				targetUrl="Error.jsp";
			}
		}
			break;
			
		case "/play":
			
			HttpSession sess=request.getSession(false);
			u= (User) sess.getAttribute("user");
			
			double gameamt=Double.parseDouble(request.getParameter("gameAmt"));
			String gamename=request.getParameter("gameName");
			request.setAttribute("gameName", gamename);
			
			double userAmt=u.getCardAmt();
			
			if(userAmt>=gameamt)
			{
				double cardAmt=userAmt-gameamt;
				u.setCardAmt(cardAmt);
				
				sess.setAttribute("user", u);
				request.setAttribute("userAmt", cardAmt);
				targetUrl="Success.jsp";
			}
			else
			{
				targetUrl="Topup.jsp";
			}
			break;
		}
		
	RequestDispatcher disp=request.getRequestDispatcher(targetUrl);
	disp.forward(request, response);
}
}


