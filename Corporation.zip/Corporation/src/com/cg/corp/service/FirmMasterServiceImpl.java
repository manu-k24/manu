package com.cg.corp.service;

import java.util.List;

import com.cg.corp.dao.FirmMasterDao;
import com.cg.corp.dao.FirmMasterDaoImpl;
import com.cg.corp.dto.FirmMaster;
import com.cg.corp.exception.FirmException;


public class FirmMasterServiceImpl implements FirmMasterService
{
    FirmMasterDao fmDao=new FirmMasterDaoImpl();

    @Override
    public List<FirmMaster> getAllData() throws FirmException 
    {
        return fmDao.getAllData();
    }

    @Override
    public FirmMaster getFirmData(long firmId) throws FirmException
    {
        return fmDao.getFirmData(firmId);
    }

    @Override
    public long addFirmDetails(FirmMaster firm) throws FirmException 
    {

        return fmDao.addFirmDetails(firm);
    }

}