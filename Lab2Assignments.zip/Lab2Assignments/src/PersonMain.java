
public class PersonMain 
{
	private String firstName;
	private String lastName;
	private char gender;
	private int age;
	private float weight;
	private String mobNo;
	
	//Default values
	
	Person p1=new Person("9026152351");
	
	//Method for displaying person details
	
	
	
	public String dispPersonInfo()
	{
		return "First Name: "+firstName+"\nLast Name: "+lastName+"\nAge: "+age+"\nMobile Number: "+mobNo ;
	}
}
