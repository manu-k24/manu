
public class PersonInfoUseGetterSetter
{

	public static void main(String[] args) 
	{
		Person p1=new Person();
		
		p1.setFirstName("Manali");
		p1.setLastName("Kadam");
		p1.setAge(22);
		
		System.out.println("First Name: "+p1.getFirstName());
		System.out.println("Last Name: "+p1.getLastName());
		System.out.println("Age: "+p1.getAge());
		
	}

}
