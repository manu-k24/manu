import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;


public class TestPropertyFileDemo 
{

	public static void main(String[] args) 
	{
		
		FileReader fr=null;
		Properties props=null;
		try 
		{
			fr=new FileReader("userInfo.properties");
			props=new Properties();
			props.load(fr);
			System.out.println(" ****all data****"+props.size());
			String unm=props.getProperty("username");
			String pwd=props.getProperty("password");
			String loc=props.getProperty("location");
			String state=props.getProperty("state");
			
			System.out.println("User Name:  "+unm+"\nPassword: "+pwd+"\nlocation: "+loc+"\nstate: "+state);
			
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}

	}

}
