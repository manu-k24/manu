import java.util.Scanner;

		public class TestDateDemo1
		{

			public static void main(String[] args) 
			{
				Scanner sc=new  Scanner(System.in);
				
				System.out.println("Enter Day: ");
				int dayOfDOJ=sc.nextInt();
				
				System.out.println("Enter Month: ");
				int monOfDOJ=sc.nextInt();
				
				System.out.println("Enter Year: ");
				int yearOfDOJ=sc.nextInt();
				
				Date manaliDOJ=new Date(dayOfDOJ, monOfDOJ, yearOfDOJ);
				System.out.println("Mnali's date of joining is: "
						+manaliDOJ.dispDate());
				
			
			}
		
		}


	


