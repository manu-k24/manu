
public class TestStudentBeanDemo 
{

	public static void main(String[] args) 
	{
		Student s1=new Student();
		s1.setRollNo(111);
		s1.setStuName("pravin");
		s1.setMarks(55);
		
		System.out.println("Roll No: "+s1.getRollNo());
		System.out.println("Student Name: "+s1.getStuName());
		System.out.println("Student Marks: "+s1.getMarks());
		
		Student s2=new Student();
		s2.setRollNo(115);
		s2.setStuName("prabha");
		s2.setMarks(75);
		
		System.out.println("Roll No: "+s2.getRollNo());
		System.out.println("Student Name: "+s2.getStuName());
		System.out.println("Student Marks: "+s2.getMarks());
		
		Student s3=new Student();
		s3.setRollNo(116);
		s3.setStuName("parimala");
		s3.setMarks(65);
		
		System.out.println("Roll No: "+s3.getRollNo());
		System.out.println("Student Name: "+s3.getStuName());
		System.out.println("Student Marks: "+s3.getMarks());
	}

}
