package com.cg.user.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SuccessPage")
public class SuccessPage extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	ServletConfig cg=null;
    public SuccessPage() 
    {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		cg=config;
	}

	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter pw=response.getWriter();
		HttpSession ses=request.getSession(true); 
		String nm=(String)ses.getAttribute("UserNameObj");
		
		pw.println("<b><h1>Welcome to EMS</h1></br>"+nm);
		pw.println("<b>U r a valid user</br>");
		pw.println("<hr color='green' size='3'/>");
		pw.println("U can perform allEmp Operation<br/>");
		pw.println("<a href=''>Add Emp</a><br/>");
		pw.println("<a href=''>List All Emp</a><br/>");
		pw.println("<a href=''>Delete All Emp</a><br/>");
		pw.println("<a href=''>Update All Emp</a><br/>");
	}

}
