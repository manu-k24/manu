package com.cg.mobilemgm.bean;

import java.sql.Date;

public class PurchaseDetails 
{
	private long purId;
	private String custName;
	private String custEmail;
	//private long millis=System.currentTimeMillis();  
	private java.sql.Date purDate;//=new java.sql.Date(millis);
	private String custPhoneNo;
	private Mobiles mobDetail;
	public long getPurId() {
		return purId;
	}
	public void setPurId(long purId) {
		this.purId = purId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	
	public java.sql.Date getPurDate() {
		return purDate;
	}
	public void setPurDate(java.sql.Date purDate) {
		this.purDate = purDate;
	}
	public String getCustPhoneNo() {
		return custPhoneNo;
	}
	public void setCustPhoneNo(String custPhoneNo) {
		this.custPhoneNo = custPhoneNo;
	}
	public Mobiles getMobDetail() {
		return mobDetail;
	}
	public void setMobDetail(Mobiles mobDetail) {
		this.mobDetail = mobDetail;
	}
	public PurchaseDetails() {
		super();

	}
	public PurchaseDetails(long purId, String custName, String custEmail,
			 Date purDate, String custPhoneNo, Mobiles mobDetail) {
		super();
		this.purId = purId;
		this.custName = custName;
		this.custEmail = custEmail;
		this.purDate = purDate;
		this.custPhoneNo = custPhoneNo;
		this.mobDetail = mobDetail;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purId=" + purId + ", custName=" + custName
				+ ", custEmail=" + custEmail + 
				 ", purDate=" + purDate + ", custPhoneNo=" + custPhoneNo
				+ ", mobDetail=" + mobDetail.toString() + "]";
	}

}
