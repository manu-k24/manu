package com.cg.mobapp.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mobapp.bean.Mobile;
import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.dao.MobDao;
import com.cg.mobapp.dao.MobDaoImpl;
import com.cg.mobapp.dao.PurchaseDao;
import com.cg.mobapp.dao.PurchaseDaoImpl;
import com.cg.mobapp.exception.MobileException;

public class MobServiceImpl implements MobService
{
	MobDao mobDao=null;
	PurchaseDao purDao=null;
	public MobServiceImpl()
	{
		mobDao=new MobDaoImpl();
		purDao = new PurchaseDaoImpl();
	}
	@Override
	public int addMob(Mobile mob) throws MobileException
	{
		return mobDao.addMob(mob);
	}
	
	@Override
	public ArrayList<Mobile> getAllMob() throws MobileException
	{
	
		return mobDao.getAllMob();
	}
	@Override
	public int delMob(int mobid) throws MobileException 
	{
		
		return mobDao.delMob(mobid);
	}
	//**************************************************************************
	@Override
	public boolean validateMobid(ArrayList<Mobile> mobList, int mobileId)
			throws MobileException 
	{
		String numPattern="[0-9]{4}";
		int flag=0;
		if(Pattern.matches(numPattern,new Integer(mobileId).toString()))
		{
			ArrayList<Mobile> mobIdList=mobDao.getAllMob();
			for(Mobile tempMobIdList:mobIdList)
			{
				if (mobileId==tempMobIdList.getMobId())
				{
					flag=1;
				}
			}
		}
		if (flag==1)
		{
			return true;
		}
		else
		{
			throw new MobileException("Only minimum 4 digits And From the List in Mobile ID");
		}
			
	}
	//**********************************************************************************
	@Override
	public int addPurchase(PurchaseDetails purchase) throws MobileException
	{
		return purDao.addPurchase(purchase);
	}
	@Override
	public int generatePurchaseId() throws MobileException
	{
		return purDao.generatePurchaseId();
	}
	//*************************************************************************************
	@Override
	public boolean validateName(String custName) throws MobileException {
		String namePattern="[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern, custName))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only characters allowed and starts with Capital e.g. Vaishali");
		}	
	}
	//***************************************************************************************
	@Override
	public boolean validateMailId(String mailId) throws MobileException 
	{
		String email="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
				
				if(Pattern.matches(email, mailId))
				{
					return true;
				}
				else
				{
					throw new MobileException("Enter valid EmailId");
				}
	}
	//**************************************************************************************
	@Override
	public boolean validatePhoneNo(String phoneNo) throws MobileException
	{
		String numPattern="[7-9][0-9]{9}";   //"[0-9]{10}$"
		if(Pattern.matches(numPattern,phoneNo ))
		{
			return true;
		}
		else
		{
			throw new MobileException("Enter valid Phone No");
		}	
	}
	//**************************************************************************************
	@Override
	public int UpdateMobQty(int mobid) throws MobileException
	{
		return mobDao.UpdateMobQty(mobid);
	}
	//**************************************************************************************
	@Override
	public ArrayList<Mobile> searchMobile(float min, float max) throws MobileException 
	{		
		return mobDao.searchMobile(min, max);
	}
}

