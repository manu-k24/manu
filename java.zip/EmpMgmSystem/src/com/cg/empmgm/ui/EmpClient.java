package com.cg.empmgm.ui;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.exception.EmployeeException;
import com.cg.empmgm.service.EmpService;
import com.cg.empmgm.service.EmpServiceImpl;
public class EmpClient 
{

	static Scanner sc=null;
	static EmpService empSer=null;               //service class object
	
	public static void main(String[] args) 
	{
		empSer=new EmpServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("What do u want to do?");
			System.out.println("1. Add Emp\t 2. Fetch All Emp\t 3.Delete\t 4. Update\t 5. Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:	insertEmp();	
					break;
			case 2:	fetchAllEmp();
					break;
			case 3:	delEmp();
					break;
			case 4:	updateEmp();
					break;
			default: System.exit(0);
			}
			
		}
		
	}
	//**************main ends here*******************
		public static void insertEmp()
		{
			System.out.println("Enter EmpName: ");
			String enm=sc.next();
			float esl=0.0f;
			try 
			{
				if(empSer.validateName(enm))
				{
					System.out.println("Enter Salary: ");
					esl=sc.nextFloat();
					Employee ee=new Employee();
					ee.setEmpName(enm);
					ee.setEmpSal(esl);
					int dataAdded=empSer.addEmp(ee);
					if (dataAdded==1)
					{
						System.out.println("Emp Data Added:");
					}
					else
					{
						System.out.println("May be some Exception while addition");
					}
				}
			} 
			catch (EmployeeException e) 
			{
				System.out.println(e.getMessage());
			}
		}
		//*******************************************
		public static void fetchAllEmp()
		{
			try 
			{
				ArrayList<Employee> empList=empSer.getAllEmp();
				for(Employee ee:empList) 
				{
					System.out.println(ee);
				}
			} 
			catch (EmployeeException e)
			{
				System.out.println("Some exception while fetching data");
				e.printStackTrace();
			}
		}
		//*******************************************
		public static void delEmp()
		{
			System.out.println("Enter the Employee Id: ");
			int eid=sc.nextInt();
			
			try 
			{
				if(empSer.validateDigit(eid))
				{
					int dataDeleted=empSer.delEmp(eid);
					if (dataDeleted==1)
					{
						System.out.println("Emp Data Deleted:");
					}
					else
					{
						System.out.println("May be some Exception while Deletion");
					}
				}
			}
			catch (EmployeeException e) 
			{
				System.out.println(e.getMessage());
			}
		}
		//*******************************************
		public static void updateEmp()
		{
			
		}

}











