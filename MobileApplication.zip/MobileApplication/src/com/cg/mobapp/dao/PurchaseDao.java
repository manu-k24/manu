package com.cg.mobapp.dao;

import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.exception.MobileException;

public interface PurchaseDao 
{
	public int addPurchase(PurchaseDetails purchase) throws MobileException;
	public int generatePurchaseId() throws MobileException;
}
