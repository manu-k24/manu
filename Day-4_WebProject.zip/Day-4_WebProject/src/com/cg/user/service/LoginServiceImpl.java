package com.cg.user.service;

import java.sql.SQLException;

import com.cg.user.dao.LoginDao;
import com.cg.user.dao.LoginDaoImpl;
import com.cg.user.dto.Login;

public class LoginServiceImpl implements LoginService
{
	LoginDao loginDao=null;
	
	public LoginServiceImpl()
	{
		loginDao=new LoginDaoImpl();
	}
	
	@Override
	public Login getUserByUnm(String unm) throws SQLException 
	{
		return loginDao.getUserByUnm(unm);
	}

}
