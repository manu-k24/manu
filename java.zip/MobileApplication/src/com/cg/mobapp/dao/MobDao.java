package com.cg.mobapp.dao;

import java.util.ArrayList;

import com.cg.mobapp.bean.Mobile;
import com.cg.mobapp.exception.MobileException;

public interface MobDao 
{
	public int addMob(Mobile mob) throws MobileException;
	public ArrayList<Mobile> getAllMob() throws MobileException;
	public int delMob(int mobid) throws MobileException;
	public int UpdateMobQty(int mobid) throws MobileException;
	public ArrayList<Mobile> searchMobile(float min,float max) throws MobileException;
}
