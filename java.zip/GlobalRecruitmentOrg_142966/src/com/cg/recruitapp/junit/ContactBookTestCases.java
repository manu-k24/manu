package com.cg.recruitapp.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.recruitapp.bean.ContactBook;
import com.cg.recruitapp.dao.ContactBookDao;
import com.cg.recruitapp.dao.ContactBookDaoImpl;
import com.cg.recruitapp.exception.ContactBookException;

public class ContactBookTestCases 
{
	static ContactBookDao contactdao=null;
	static ContactBook cc=null;
	
	
	@BeforeClass
	public static void beforeClass() throws ContactBookException
	{
		contactdao=new ContactBookDaoImpl();
		cc=new ContactBook(contactdao.generateEnquiryId(),"Manali","Kadam","9865852635","Java","Mumbai");
	}
	
	@Test
	public void testAddEnquiry1() throws ContactBookException
	{		
			Assert.assertEquals(1, contactdao.addEnquiry(cc));		
	}
	
	@Test(expected=Exception.class)
	public void testAddEnquiry2() throws ContactBookException
	{		
			Assert.assertEquals(1, contactdao.addEnquiry(cc));		
	}
}
