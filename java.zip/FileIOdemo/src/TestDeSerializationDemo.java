import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
public class TestDeSerializationDemo 
{

	public static void main(String[] args) 
	{	
		Emp e1=new Emp();
		try
		{
			FileInputStream fis=new FileInputStream("EmpData.obj");
			ObjectInputStream ois=new ObjectInputStream(fis);
			e1=(Emp)ois.readObject();  //type casting is required
			System.out.println(e1);
			System.out.println("Emp object is written in a file");
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		
		
		
	}
	
}