
public class TestStaticEmpDemo 
{
	 
	static
	{
		System.out.println("This is TestStaticEmpDemo static block");
	}
	public static void main(String[] args) 
	{
		System.out.println("Main starts here");
		
		Emp e1=new Emp(111,"Manali",1000.0F);
		Emp e2=new Emp(112,"Vrushali",2000.0F);
		Emp e3=new Emp(113,"Rupali",3000.0F);
		
		System.out.println(e1.dispEmpInfo());
		System.out.println(e2.dispEmpInfo());
		System.out.println(e3.dispEmpInfo());
		
		Emp.getCount();
		show();
	}
	
	public static void show()
	{
		System.out.println("Show");
	}

}
