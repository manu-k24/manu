//only print key values
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;


public class TestHashMapKeysOnly 
{

	public static void main(String[] args) 
	{
		

		HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
		mobileDirectory.put(9026853221L, "Shilpa");
		mobileDirectory.put(8026853221L, "Shushma");
		mobileDirectory.put(5026853221L, "Shiya");
		mobileDirectory.put(7026853221L, "Shile");
		mobileDirectory.put(9026853221L, "Shilpa");
		
		Set setIt=mobileDirectory.keySet();
		Iterator mobIt=setIt.iterator();
		while(mobIt.hasNext())
		{
			
			System.out.println("Mobile: "+mobIt.next());//+"Name: "+dirEntry.getValue());    
			
		}
		
	}

}
