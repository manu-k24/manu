function sayHello()
{
//TODO:return the string “Hello World“
var str = document.write("This text is displayed by Calling external function:<b>Hello World </b>");
return str;
}