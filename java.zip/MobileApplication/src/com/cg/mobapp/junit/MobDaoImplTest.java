package com.cg.mobapp.junit;
import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobapp.bean.Mobile;
import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.dao.MobDao;
import com.cg.mobapp.dao.MobDaoImpl;
import com.cg.mobapp.exception.MobileException;

public class MobDaoImplTest
{
    static MobDao mobDao = null;
    static Mobile mob = null;
    static int mobId = 1004;
    static float min = 3000;
    static float max = 40000;
    
    @BeforeClass
    public void beforeClass() throws MobileException
    {
        mobDao = new MobDaoImpl();
        mob = new Mobile(1002,"Nokia Lumia 520",8000,20);
    }
    
    @Test
    public void testDeleteMob1() throws MobileException
    {
        Assert.assertEquals(0, mobDao.delMob(mobId));
    }
    
    @Test
    public void testFetchAllMob() throws MobileException
    {
        Assert.assertNotNull(mobDao.getAllMob());
    }
    
    @Test
    public void testGetMobId() throws MobileException
    {
        Assert.assertNotNull(mobDao.getAllMob());
    }
    
    @Test
    public void testSearchMob() throws MobileException
    {
        Assert.assertNotNull(mobDao.searchMobile(min, max));
    }
}
