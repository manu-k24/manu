package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
//import java.io.PrintWriter;
import java.sql.SQLException;


//import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import com.cg.dto.Registration;
import com.cg.service.RegistrationServiceImpl;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet
{
	
	Registration register=null;

	RegistrationServiceImpl  registerService=null;
	private static final long serialVersionUID = 1L;
 
    public RegistrationServlet()
    {
        super();
        
    }

	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	public void destroy()
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//PrintWriter out=response.getWriter();
		registerService=new RegistrationServiceImpl();    //service will comm with servlet
		
		String fname=request.getParameter("txtFName");
		String lname=request.getParameter("txtLName");
		String pwd=request.getParameter("txtPwd");
		String gender=request.getParameter("gender");
		String[] skillstr=request.getParameterValues("abc");
		String city=request.getParameter("city");
		int n=skillstr.length;
		String skill=skillstr[0];
		if(n==1)
		{
			skill=skillstr[0];
		}
		else
		{
			while(n>1)
			{
				skill=skill+","+skillstr[n-1];
				n=n-1;
			}
		}
		register= new Registration(fname,lname,pwd,gender,skill,city);
		try 
		{
			int dataAdded=0;
			
			dataAdded=registerService.insertDetails(register);			
			System.out.println("DataAdded..."+ dataAdded);
			PrintWriter out=response.getWriter();
			
			if(dataAdded==1)    //or  if(dataAdded !=0 )
			{
				response.sendRedirect("htmls/Success.html");
			}
		
			else
			{
				response.sendRedirect("htmls/Failure.html");
			}
		} 
	catch (SQLException e)
	{		
		e.printStackTrace();
	}
	}

}

